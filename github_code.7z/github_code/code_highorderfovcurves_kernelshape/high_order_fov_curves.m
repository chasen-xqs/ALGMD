syms t; %定义x是一个未知量
% syms l; %l_0/v表述为l,
l_0=0.5;
v0=1;
a=min(sign(t+2),1.5.*sign(t+1.2));
% v=v0+a.*t
l=l_0./v0;
% l=0.02;

theta=1*atan(l./t);
theta_1=-l/(l^2 + t^2);%一阶导数
theta_2=(2*l*t)/(l^2 + t^2)^2;%二阶导数
theta_3=-(-2*l^3 + 6*l*t^2)/(l^2 + t^2)^3;
theta_4=-(24*l*t*(l^2 - t^2))/(l^2 + t^2)^4;
theta_5=-(24*l*(l^4 - 10*l^2*t^2 + 5*t^4))/(l^2 + t^2)^5;

% simplify(theta_5)
% solve(theta_5==0,t)
% diff(theta_4)
% solve(theta_5==0,t)%
%plot
%normolized
% Theta=double(subs(theta))
% theta_max=max(theta);
% 
% normalize(theta)
% theta_1_max=max(theta_1);
% theta_2_max=max(theta_2);
% theta_3_max=max(theta_3);
% theta_4_max=max(theta_4);
% theta_5_max=max(theta_5);

figure(5)
hold on
l=0.5 
% max=1.36 2 2.6 4 6.8
fplot(-theta./1,[-10*l,-0.01],'r','linewidth',2)
fplot(-theta_1./1,[-10*l,-0.01],'g','linewidth',2)
fplot(-theta_2./1,[-10*l,-0.01],'b','linewidth',2)
fplot(-theta_3./1,[-10*l,-0.01],'m','linewidth',2)
fplot(-theta_4./1,[-10*l,-0.01],'k','linewidth',2)


% fplot(-theta_2./1,[-10,-0.01],'linewidth',2)
% max(-theta_2)
%normal
% fplot(-theta./1.36,[-10*l,-0.01],'r','linewidth',2)
% fplot(-theta_1./2,[-10*l,-0.01],'g','linewidth',2)
% fplot(-theta_2./2.6,[-10*l,-0.01],'b','linewidth',2)
% fplot(-theta_3./4,[-10*l,-0.01],'m','linewidth',2)
% fplot(-theta_4./6.8,[-10*l,-0.01],'k','linewidth',2)

title('Field of view angle curves of each order(l/v=0.5)')
axis([-10*l -0.01 0 7]);
legend('\theta','d\theta/dt','d^2\theta/dt','d^3\theta/dt','d^4\theta/dt','Location','best')
% legend('l/v=0.2','l/v=0.1','l/v=0.08','l/v=0.04','l/v=0.02','Location','best')
xlabel('TTC(time to collision)/s');

% %去掉坐标轴刻度
% t=0:0:0;
% set(gca,'ytick',t); 
% 去掉坐标轴
ax=gca
ax.YAxis.Visible='off';

% eqn=-2.*(sin(theta).*(cos(theta)^5)+3.*(sin(theta)^3).*(cos(theta)^3)+2.*(sin(theta)^2).*(cos(theta))^3)./t^3==0; % 定义方程，eqn只是一个代号，代表sin(x)==1
% solX=solve(eqn,theta) % 求方程eqn中的x，放入solX中
% solY=solve(eqn,t) % 求方程eqn中的x，放入solX中

% figure(1)
% hold on
% %l=0.1 max=1.47 10 65 500 4210
% fplot(-theta./1.47,[-10*l,-0.01],'r','linewidth',2)
% fplot(-theta_1./10,[-10*l,-0.01],'g','linewidth',2)
% fplot(-theta_2./65,[-10*l,-0.01],'b','linewidth',2)
% fplot(-theta_3./500,[-10*l,-0.01],'m','linewidth',2)
% fplot(-theta_4./4210,[-10*l,-0.01],'k','linewidth',2)
% % fplot(-theta_5,[-10*l,-0.01],'c','linewidth',2)
% axis([-10*l -0.01 0 1]);
% legend('\theta     l/v=0.1','d\theta/dt     l/v=0.1','d^2\theta/dt     l/v=0.1','d^3\theta/dt     l/v=0.1','d^4\theta/dt     l/v=0.1','Location','North')