function val = kernel_plot(sigma,r,p)%p=0 低速滤波核，p=1 高速滤波核
% 110
% 221
%-------------------version1-----------
% o=(d+1)/2;
% Z=zeros(d,d);
% for a=1: d
%     for b=1: d
%         if (a-o)^2+(b-o)^2<=r^2
%             Z(a,b)=2;
%         end
%     end
% end
% %-------------------version2-----------
% x=-r:1:r;
% y=-r:1:r;
%plot
m=100;%画图稀疏程度
x=-r:1/m:r;
y=-r:1/m:r;

[X,Y]=meshgrid(x,y);

amplitude = 1 / (2*pi*sigma^2); 
exponent1 = ((X).^2 + (Y).^2)./(2*sigma.^2);
if p==0
    Z=amplitude  * (1-exp(-exponent1));%选低速
else
    Z=amplitude  * exp(-exponent1);
end
Z(Z==0)=10;
min(min(Z));
k=round(1/min(min(Z)));
Z(Z==10)=0;
% k=1;

for a=1:2*m*r+1
    for b=1: 2*m*r+1
        if ((a-m*r-1)^2+(b-m*r-1)^2)>(m*r)^2
            Z(a,b)=0;
            Z(a,b)=NaN;
        else
            Z(a,b)=Z(a,b)*k;
        end
    end
end
% Z(Z>2)=2;
% Z(m*r+1,m*r+1)=1;
%plot
% x=-r:0.001:r;
% y=-r:0.001:r;
% figure(1)
% Fig = mesh(X,Y,Z); 
% axis off

%-----------------r=2
Z=Z/2667;
%-----------------r=2
figure(1)
subplot(1, 2, 1);
mesh(X, Y, Z); 
xlabel('X');
ylabel('Y');
zlabel('Z');
% axis off
% title('原始图');

% 绘制俯视图
subplot(1, 2, 2);
contourf(X, Y, Z, 20);  % 使用等高线绘制俯视图
xlabel('X');
ylabel('Y');
% axis off
% title('俯视图');
% colorbar;  % 添加颜色条
% % 自定义 colorbar 标签

val       =Z;