clear;clc;
%**************Claimed Parameters********************************
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\real world\d=5 v=2 looming\';FrameEnd_Num =72;
%--------------------240320--------------
FrameSTRT_Num=1;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\box\';FrameEnd_Num =33;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\ball\';FrameEnd_Num =37;
% % % 
% % % FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\chair\';FrameEnd_Num =120;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\chair\';FrameEnd_Num =120;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\QRcode_0.5\';FrameEnd_Num =134;
% % % % 
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV3_movingcar\';FrameEnd_Num =32;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV2_basketballstick\';FrameEnd_Num =54;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV4_uav\';FrameEnd_Num =42;
%-------------------------------ALGMD----------------
%------------------------------kernel-----------------------------------
r1=1;  
kernel_I2=1*kernel(r1,r1,0);%参数（sigma，卷积核半径，卷积核类型0 or 1）%0是选低速，1是选高速
r2=2;
kernel_I3=kernel(r2,r2,1);
r_A=2*r2-r1+1;
kernel_A=ones(2*r_A+1);
%---------izhikevich parament---------
k=1;%计量神经元模型的个数
a=0.02;
b=0.2;
c=-65;
d=2;
v=zeros(1,FrameEnd_Num);
u=zeros(1,FrameEnd_Num);
v(1)=-65;
u(1)=0;
%----------遍历文件夹图片，当指定开始和结束帧时注释下面代码
% fileExt = '*.bmp';  %待读取图像的后缀名
% %获取所有路径
% files = dir(fullfile(FilePath,fileExt)); 
% FrameEnd_Num = size(files,1);
% FrameEnd_Num =134;
%-------------神经脉冲尖峰信息存储
A_num=zeros(1,FrameEnd_Num);
V3_num=zeros(1,FrameEnd_Num);
Soma=zeros(1,FrameEnd_Num);

q=zeros(1,FrameEnd_Num);%frams
w=zeros(1,FrameEnd_Num);%spike intensity
spike=0;
%*********************************setup***************
[img_past,img_now,img_diff1,img_diff2,img_diff3]=deal(zeros());
ii=0;%读取多少张
i=0;%除去相同的图片，有效的差分图张数
flag=1;%
tic;
t1 = toc;
% i=120;
while flag==1 && ii<FrameEnd_Num
    ii=ii+1;
    FileName = strcat (FilePath,num2str(ii),'.bmp'); 
    temp=imread(FileName);
    %240*320将图片归一化刀240320的分辨率
    img_now=imresize(im2single(temp),[240,320]);%会导致取点不连续
%     img_now=imresize(im2single(temp),1);
    img_diff3=abs(img_now-img_past);
    sum(sum(img_diff3))
%     if sum(sum(img_diff3))==0   
%         continue
%     else
%         i=i+1;
%         ii;
%     end
    i=i+1;
    if  i>2 
        %-----------ALGMD-----------------
        Layer_V2=(img_diff2-conv2(img_diff1,kernel_I2,'same')); 
        Layer_V23=(img_diff2-conv2(img_diff1,kernel_I3,'same')); 
        Layer_V3=(img_diff3-conv2(img_diff2,kernel_I3,'same'));

        %求加速度信息
        Layer_V3(Layer_V3<0.1)=0;
        Layer_temp = conv2(Layer_V3,kernel_A,'same');
        Layer_A=Layer_temp.*imbinarize(Layer_V2,0.03).*abs((imbinarize(Layer_V23,0.1)-1));
% %         %计算具有速度，加速度的像素点个数
        A_num(i)=sum(sum(Layer_A>0.1));
        V3_num(i)=sum(sum(Layer_V3>0));
        Soma(i)=A_num(i)*V3_num(i);
        %old PDS
%         Output_temp(i)=max(0,A_num(i)-V3_num(i));    
%         Output(i)=Output_temp(i).*V3_num(i);
        %-------------------------izhikevich----------------
        k=k+1;
        [v(k),u(k)]=Izhikevich_model(v(k-1),u(k-1),Soma(i),10^-3*k/30,a,b);%v,u,I,t,a,b
        if v(k)>=30
            v(k)=c;
            u(k)=u(k-1)+d;
        end
%         终止条件和记录脉冲        
        if k>3 && v(k-1)>v(k) && v(k-1)>v(k-2) && v(k-1)>-25
            spike=spike+1;
            q(spike)=i-2;
            w(spike)=v(q(spike));
        end
        s4(i)=sum(sum(Layer_A>0));
        xxx=mapminmax(s4,0,1);
    end

    img_past=img_now;
    img_diff1=img_diff2;
    img_diff2=img_diff3;
end
t2 = toc;
RunTime = t2-t1
%---------spike---
% figure(232323)
% hold on
% yyaxis left
% ylabel("Number of dangerous pixel")  
% % plot(V2_num,'linewidth',2)
% % plot(Soma,'linewidth',2)
% % plot(A_num,'linewidth',2)
% % plot(V3_num)
% 
% yyaxis right
% ylabel("ALGMD's neural spike")  
% plot(v,'linewidth',2)
% % plot(v,'linewidth',2)
% plot(q(1),w(1),'rs') 
% % text(q(1),w(1),['Trigger'])
% % text(q(1)-40,w(1),['Trigger(' num2str(q(1)) ',' num2str(w(1)) ')'])
% legend('Number of Layer A ','Neural spike','Trigger','location','NorthWest')
% q(1)
%------------------------------LGMD-----------------------
sigma_E = 1.5; %0.4:0.02:1; %0.4:0.02:1.5;     %distributed excitation
sigma_I = 5;%1.6:0.08:4; %1.6:0.08:6;
Max_delay =3;

a = 1.2;%1.2~1.8  
b = 4;
r = 6;
Thresh_G_0 = 0.5;
alfa = -0.1;%-0.1,-0.6;
beta = 0.5;%0.5,0.4;
lamda = 0.7;%0.7,0.6;
%****************define h(t)***************************************
x = -r:1:r;
y = -r:1:r;
for i= 1:(r*2+1)
    for j = 1:(r*2+1)
        ht(i,j)= alfa + 1./(beta+ exp(-((x(i)*lamda).^2+(y(j)*lamda).^2)));
    end
end
ht(ht<1) =0;
%***************D-LGMD************************************
% for k = 1:1
for k = 1:length(sigma_E)
    for h = 1:length(sigma_I)
%*********Classic LGMD **********
%     kernel_I = [0.3535 0.4472 0.5 0.4472 0.3535; 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.5 1 0 1 0.5 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.3535 0.4472 0.5 0.4472 0.3535];
    kernel_I = [0.125 0.25 0.125
                0.25 0 0.25
                0.125 0.25 0.125];
%     kernel_I = a.* kernel_I
    kernel_E = 1;       
%***************************************************
tic;
t1 = toc;
    for i=FrameSTRT_Num+Max_delay:FrameEnd_Num
        FileName = strcat (FilePath,num2str(i-3),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i-2),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame3 = imread(FileName);
        Frame3 = im2single (Frame3);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame4 = imread(FileName);
        Frame4 = im2single (Frame4);
        
        Frame_Diff1 = abs(Frame2 - Frame1);
        Frame_Diff2 = abs(Frame3 - Frame2);
        Frame_Diff3 = abs(Frame4 - Frame3);

       FFI(i) = sum(sum(Frame_Diff1));
       Thresh_G(i) = FFI(k,i)*0.001/200 * Thresh_G_0;
       Thresh_G(i) = min(Thresh_G(i),0.3);
       

        Layer_E = conv2(Frame_Diff3,kernel_E,'same');
        Layer_I=conv2(Frame_Diff2,kernel_I,'same');
       Layer_S = Layer_E - Layer_I;
       Layer_S(Layer_S<0) =0;      %results will not be negative.
% %*************FFM-GD***************
        Layer_G=Layer_S;
        LGMD_OutputS(k,i) = sum(sum(Layer_S));    %**output of G or S layer***
        LGMD_OutputG(k,i) = sum(sum(Layer_G));    %**output of G or S layer***

%    figure(1)
%    Video_Resize = imresize(Layer_G,0.5);
%    imshow(Video_Resize);
    end
    %*************************************************
    Normalized_OutS(k,1:i) = mapminmax(LGMD_OutputS(k,:), 0, 1);
    Normalized_OutG(k,1:i) = mapminmax(LGMD_OutputG(k,:), 0, 1);
%     G_max=max(LGMD_OutputG);
%     Normalized_OutG(k,1:i)=normal(G_max,1,LGMD_OutputG(k,:));
    end
end
t2 = toc;
RunTime = t2-t1

%----------------------DLGMD-------------------------------------
sigma_E = 1.5; %0.4:0.02:1; %0.4:0.02:1.5;     %distributed excitation
sigma_I = 5;%1.6:0.08:4; %1.6:0.08:6;

Max_delay = 3;
LGMD_OutputS = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
FFI = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
Threshold_Pnt = zeros(length(sigma_E),1);
kernalG = ones(4,4);

a = 1.2;%1.2~1.8  %第二次实验a=1
% a=0.8;
b = 4;
r = 6;
Thresh_G_0 = 0.5;
alfa = -0.1;%-0.1,-0.6;
beta = 0.5;%0.5,0.4;
lamda = 0.7;%0.7,0.6;
%****************define h(t)***************************************
x = -r:1:r;
y = -r:1:r;
for i= 1:(r*2+1)
    for j = 1:(r*2+1)
        ht(i,j)= alfa + 1./(beta+ exp(-((x(i)*lamda).^2+(y(j)*lamda).^2)));
    end
end
ht(ht<1) =0;
%***************D-LGMD************************************
% for k = 1:1
for k = 1:length(sigma_E)
    for h = 1:length(sigma_I)
%*********Classic LGMD **********
%     kernel_I = [0.3535 0.4472 0.5 0.4472 0.3535; 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.5 1 0 1 0.5 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.3535 0.4472 0.5 0.4472 0.3535];
% %     kernel_I = [0.125 0.25 0.125
% %                 0.25 0 0.25
% %                 0.125 0.25 0.125];
    %     kernel_I = a.* kernel_I
%     kernel_E = 1;       
%**********distributed excitation and inhibition kernels***********    
    Tempkernel = DOGAnalysis(a, sigma_I(h)/sigma_E(k) , sigma_E(k), r ,k);  %Func(a,b,sigma,r);
    kernel_E = GaussAnalysis(sigma_E(k),r);
    kernel_E(ht<1) = Tempkernel(ht<1);   %To form distributed time delay, which is determined by the h(t) distribution.(Self-inhibition involved here)
    kernel_E(ht>1) = 0;
    kernel_E(kernel_E<0) = 0;
    Showkerne_E = round (kernel_E*100);

    kernel_I = a * GaussAnalysis(sigma_I(h),r);
    kernel_I(ht<1) =0;%(here I make the h(t) distribution in this principle: delay=0 when ht<1, otherwise delay=1)
    kernel_I_delay1 = kernel_I;

    kernel_I_delay1(ht<1) =0;
    kernel_I_delay1(ht>1.8999) =0;
    Showkernel_I_delay1 = round (kernel_I_delay1*100);
    
    kernel_I_delay2 = kernel_I;
    kernel_I_delay2(ht<1.8999) =0;
    Showkernel_I_delay2 = round (kernel_I_delay2*100);
%***************************************************
tic;
t1 = toc;
    for i=FrameSTRT_Num+Max_delay:FrameEnd_Num
        FileName = strcat (FilePath,num2str(i-3),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i-2),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame3 = imread(FileName);
        Frame3 = im2single (Frame3);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame4 = imread(FileName);
        Frame4 = im2single (Frame4);
        
        Frame_Diff1 = abs(Frame2 - Frame1);
        Frame_Diff2 = abs(Frame3 - Frame2);
        Frame_Diff3 = abs(Frame4 - Frame3);

       FFI(i) = sum(sum(Frame_Diff1));
       Thresh_G(i) = FFI(k,i)*0.001/200 * Thresh_G_0;
       Thresh_G(i) = min(Thresh_G(i),0.3);
       
%       (Note: Layer_I = currentframe (conv) kernel_I_delay0 + delayed_1frame (conv)
%       kernel_I_delay1 +delayed_2frame (conv) kernel_I_delay2)
        Layer_E = conv2(Frame_Diff3,kernel_E,'same');
        Layer_I_delay1 = conv2(Frame_Diff2,kernel_I_delay1,'same');
        Layer_I_delay2 = conv2(Frame_Diff1,kernel_I_delay2,'same');
        Layer_I = Layer_I_delay1 + Layer_I_delay2;  %delay0 has been involved to kernal E.
        
       Layer_S = Layer_E - Layer_I;
       Layer_S(Layer_S<0) =0;      %results will not be negative.
       
       sum_p=sum(sum(Frame_Diff3));
        sum_s=sum(sum(Layer_S));
%         PS=sum_s/sum_p;
% %*************FFM-GD***************
       Layer_G_Cef = conv2(Layer_S,kernalG,'same');
       Layer_G =Layer_S .* Layer_G_Cef;
%        Layer_G=Layer_S;

        Layer_G(Layer_G<Thresh_G(i))=0;%change yuzhi
        Layer_G(Layer_G>1)=1;
%         Layer_G(Layer_G<0.7)=0;
%          LGMD_OutputPS(k,i) = PS;

        LGMD_OutputS(k,i) = sum(sum(Layer_S));    %**output of G or S layer***
        LGMD_OutputG(k,i) = sum(sum(Layer_G));    %**output of G or S layer***
%         LGMD_OutputG(k,i) = sum(sum(Layer_G~=0)); 
%         imwrite(Layer_G,strcat('C:\Users\Administrator\Desktop\acc\论文撰写\figures\68\imwrite\',num2str(i),'.bmp'));

%    figure(1)
%    Video_Resize = imresize(Layer_G,1);
%    imshow(Video_Resize);
%    title(strcat('G',num2str(i)));
    end
    %*************************************************
    Normalized_OutS(k,1:i) = mapminmax(LGMD_OutputS(k,:), 0, 1);
    DNormalized_OutG(k,1:i) = mapminmax(LGMD_OutputG(k,:), 0, 1);
%     Normalized_OutPS(k,1:i) = mapminmax(LGMD_OutputPS(k,:), 0, 1);


%         G_max=max(LGMD_OutputG);
%     Normalized_OutG(k,1:i)=normal(G_max,1,LGMD_OutputG(k,:));
    end
end
t2 = toc;
RunTime_LGMD = t2-t1
%----------------------------------------------------
%--------计算attc和far-------------
figure(1314)
hold on
plot(1:FrameEnd_Num,xxx,'linewidth',2,'linestyle','-')
for k = 1:length(sigma_E)
    figure (1314)
    hold on
%     plot (1:i,Normalized_OutS(k,(1:i)));
    plot (1:i,Normalized_OutG(k,(1:i)),'linewidth',2,'linestyle','-');
    plot (1:i,DNormalized_OutG(k,(1:i)),'linewidth',2,'linestyle','-');
    xlabel('Frames');
    ylabel('Normalised Output');
    legend('ALGMD','DLGMD','LGMD',Location='northwest')
end
%---------ATTC--------
ATTC_ALGMD=0.03*(FrameEnd_Num-find(xxx>0.3))
ATTC_LGMD=0.03*(FrameEnd_Num-find(Normalized_OutG>0.3))
ATTC_DLGMD=0.03*(FrameEnd_Num-find(DNormalized_OutG>0.3))

