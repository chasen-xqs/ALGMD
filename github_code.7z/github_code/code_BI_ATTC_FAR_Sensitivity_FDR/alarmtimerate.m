% %初步
% t = linspace(0,1,100); % 在 0 到 1 的范围内生成 1000 个均匀分布的时间点
% x=t;
% %LGMD
% z1 =min(100,400.*x.*x); % 误报警率
% y1 = 1-0.7.*x; % % attc
% y1(x>0.5)=0;
% %DLGMD
% z2 = 20.*x; % 误报警率
% y2 = 1.2.*x.*x-2.2.*x+1; % attc
% %ALGMD
% z3= 10.*x; % 误报警率
% y3 = 0.6.*x.*x-1.3.*x+1; % attc
% 
% % 绘制三维曲线
% figure;
% hold on
% 
% yyaxis left
% 
% plot(x, y1,'LineWidth', 2,'LineStyle',':');
% plot(x, y2,'LineWidth', 2,'LineStyle','--');
% plot(x, y3, 'LineWidth', 3,'LineStyle','-');
% ylabel('ATTC(alarm time to collision)/s');
% 
% yyaxis right
% 
% plot(x, z1, 'LineWidth', 2,'LineStyle',':');
% plot(x, z2, 'LineWidth', 2,'LineStyle','--');
% plot(x,  z3, 'LineWidth', 3,'LineStyle','-');
% 
% 
% xlabel('RBI(relative background interference)');
% ylabel('FAR(false alarm rate)/%');
% legend('LGMD','D-LGMD','A-LGMD')
% 
% title('Approximate relationship between RBI and metrics of FAR and ATTC');
% grid on;


%--------------------真实FAR和ATTC-------------------------------------
x=[0.4,2.2,11.2,21.8,40,88,172.4];
% x=[1,2,3,4,5,6,7];
%LGMD
y1_old =[0.6,0.2,0.1,0,0,0,0.03]; % % attc
y1 =1000*[0.54,0.21,0.18,0,0,0.09,0.09];
% z1 =[0.51,0.05,0.17,0.93,0.93,0.05,0.74]; % 误报警率
% z1 =[0.51,0.05,0.17,0.93,0.93,0.05,0.74]; % 运行时间
z1 =[0.28,0,0,100,100,38.86,67.17]; % 误报警率2.0
z1 =[0.15,0,0,100,100,32.39,61.72]; % 误报警率3.0

%DLGMD
y2_old = [0.17,0.23,0.07,0.1,0.47,0,0]; % attc
y2 =1000*[0.12,0.21,0.03,0.06,0.06,0,0];
y2 =1000*[0.15,0.18,0.06,0.18,0.39,0,0];
% z2 = [0.29,0.04,0.03,0.01,0.02,0.02,0.03]; % 误报警率
% z2 =[0.51,0.05,0.17,0.93,0.93,0.05,0.74]; % 运行时间
z2 =[1.57,0,0,14.29,0,63.67,32.09]; % 误报警率2.0
z2 =[0.26,0,0,0,0.11,15.16,14.75]; % 误报警率3.0

%ALGMD
y3_old =[0.6,0.37,0.23,0.67,0.7,0.37,0.3]; % attc
y3=1000*[0.84,0.39,0.3,0.3,0.39,0.18,0.06];
% z3= [0.2,0.05,0.16,0.04,0.02,0.07,0.11]; % 误报警率
% z3 =[0.51,0.05,0.17,0.93,0.93,0.05,0.74]; % 运行时间
z3 =[0,0,19.45,20.34,0,51.04,58.78]; % 误报警率2.0
z3 =[0,0,7.61,0,0.33,12.76,16.53]; % 误报警率3.0

% 绘制三维曲线
% figure;
% hold on
% plot(x, y1,'LineWidth', 2,'LineStyle',':');
% plot(x, y2,'LineWidth', 3,'LineStyle','--');
% plot(x, y3, 'LineWidth', 4,'LineStyle','-');
% ylabel('ATTC(alarm time to collision)/ms');
% legend('LGMD','D-LGMD','A-LGMD')
% title('The relationship between the ATTC and background complexity');
% grid on;


figure(3);
hold on
yyaxis left
% ,'Color',[1 0 0]
plot(log10(x), y1,'LineWidth', 2,'LineStyle',':');
plot(log10(x), y2,'LineWidth', 2.5,'LineStyle','--');
plot(log10(x), y3, 'LineWidth', 4,'LineStyle','-');
ylabel('ATTC(alarm time to collision)/ms');

yyaxis right


plot(log10(x), z1, 'LineWidth', 2,'LineStyle',':');
plot(log10(x), z2, 'LineWidth', 2.5,'LineStyle','--');
plot(log10(x), z3, 'LineWidth', 4,'LineStyle','-');

xlabel('BI(background interference)');
ylabel('FAR(false alarm rate)/%');
legend('LGMD','D-LGMD','A-LGMD','LGMD','D-LGMD','A-LGMD')

title('Relationship between BI and metrics of ATTC and FAR');
