function avg = calculateAverage(arr, index)
    % 检查输入参数是否合法
    if ~isnumeric(arr) || ~isvector(arr) || ~isnumeric(index) || ~isscalar(index)
        error('输入参数错误');
    end

    % 确保数组下标在有效范围内
    if index < 1 || index > numel(arr)
        error('数组下标越界');
    end

    % 切片数组，从第一个下标到给定下标之间
    subArr = arr(1:index);

    % 计算非零非 NaN 元素的平均值
%     validElements = subArr(isfinite(subArr) & subArr ~= 0);
%     avg = mean(validElements);
    % 将NaN元素置为0
    subArr(isnan(subArr)) = 0;

    % 计算平均值
    avg = mean(subArr);

end