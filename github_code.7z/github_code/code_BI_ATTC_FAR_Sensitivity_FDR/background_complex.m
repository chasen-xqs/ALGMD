% FrameSTRT_Num =1; 
% FrameEnd_Num =42;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\experience\FPV_collision\date\FPV4_uav\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\uav_renamed\';

% FrameSTRT_Num =1; 
% FrameEnd_Num =54;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\experience\FPV_collision\date\FPV2_basketballstick\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\basket ball_renamed\';

% FrameSTRT_Num =1; 
% FrameEnd_Num =32;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\experience\FPV_collision\date\FPV3_movingcar\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\moving car_renamed\';
% 
% FrameSTRT_Num =1; 
% FrameEnd_Num =120;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture\0.5\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\chair_mask_renamed\';

% % % FrameSTRT_Num =1; 
% % % FrameEnd_Num =134;
% % % FilePath = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture\QRcode\0.5\';
% % % FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\chair_mask_renamed\';

% FrameSTRT_Num =1; 
% FrameEnd_Num =33;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\box\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\box_mask_renamed\';

% FrameSTRT_Num =1; 
% FrameEnd_Num =37;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\ball\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\ball_mask_renamed\';

% FrameSTRT_Num =1; 
% FrameEnd_Num =134;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture\QRcode\1\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\qrcode_mask_renamed\';

for i=FrameSTRT_Num+1:FrameEnd_Num  
    FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        Frame_Diff = abs(Frame2 - Frame1);%差分

        FileName_mask = strcat (FilePath_mask,num2str(i),'.bmp');
        Frame_mask = imread(FileName_mask);
        Frame_mask = im2single (Frame_mask);
        Frame_mask = im2bw(Frame_mask,0.01);%mask
        Frame_mask_background=1.-Frame_mask;%background_mask
        figure(2)
        imshow(imresize(Frame_mask_background,[240,320]))
        
        background_noise(i)=sum(sum(Frame_Diff.*Frame_mask_background));
        looming(i)=sum(sum(Frame_Diff.*Frame_mask));
        Background_complex(i)=background_noise(i)/looming(i);
        figure(1)
        imshow(Frame_Diff.*Frame_mask_background)

end
looming(2)=0;
figure(2)
        hold on
        plot(background_noise(1:FrameEnd_Num-1))
        plot(looming(1:FrameEnd_Num-1))
      plot(Background_complex(1:FrameEnd_Num-1))


Background_complex=mean(Background_complex)