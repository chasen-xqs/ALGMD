clear;clc;
%**************Claimed Parameters********************************
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\real world\d=5 v=2 looming\';FrameEnd_Num =72;
%--------------------240320--------------
FrameSTRT_Num=1;
FilePath ='C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\box\';FrameEnd_Num=33;trigger_algmd=23;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\ball\';FrameEnd_Num =37;trigger_algmd=32;
% % % % % % % 
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\chair\';FrameEnd_Num =120;trigger_algmd=107;
% trigger_algmd=87;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\QRcode_0.5\';FrameEnd_Num =134;trigger_algmd=124;
% trigger_algmd=105;
% % % % % % % % % % 
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV3_movingcar\';FrameEnd_Num =32;trigger_algmd=19;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV2_basketballstick\';FrameEnd_Num =54;trigger_algmd=26;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV4_uav\';FrameEnd_Num =42;trigger_algmd=36;
% -------------------------------ALGMD----------------
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\box_mask_renamed\';
% FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\ball_mask_renamed\';
% % 
FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\chair_mask_renamed\';
FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\qrcode_mask_renamed\';
% % % % 
FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\moving car_renamed\';
FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\basket ball_renamed\';
FilePath_mask = 'C:\Users\Administrator\Desktop\acc_sum\date1209\picture_mask\uav_renamed\';


num_parament=0.1;
%------------------------------kernel-----------------------------------
r1=1;  
kernel_I2=1*kernel(r1,r1,0);%参数（sigma，卷积核半径，卷积核类型0 or 1）%0是选低速，1是选高速
r2=2;
kernel_I3=kernel(r2,r2,1);
r_A=2*r2-r1+1;
kernel_A=ones(2*r_A+1);
%---------izhikevich parament---------
k=1;%计量神经元模型的个数
a=0.02;
b=0.2;
c=-65;
d=2;
v=zeros(1,FrameEnd_Num);
u=zeros(1,FrameEnd_Num);
v(1)=-65;
u(1)=0;

L(2)=0;
B(2)=0;

%----------遍历文件夹图片，当指定开始和结束帧时注释下面代码
% fileExt = '*.bmp';  %待读取图像的后缀名
% %获取所有路径
% files = dir(fullfile(FilePath,fileExt)); 
% FrameEnd_Num = size(files,1);
% FrameEnd_Num =134;
%-------------神经脉冲尖峰信息存储
A_num=zeros(1,FrameEnd_Num);
V3_num=zeros(1,FrameEnd_Num);
Soma=zeros(1,FrameEnd_Num);

q=zeros(1,FrameEnd_Num);%frams
w=zeros(1,FrameEnd_Num);%spike intensity
spike=0;
%*********************************setup***************
[img_past,img_now,img_diff1,img_diff2,img_diff3]=deal(zeros());
[img_past_mask,img_now_mask]=deal(zeros());
ii=0;%读取多少张
i=0;%除去相同的图片，有效的差分图张数
flag=1;%
tic;
t1 = toc;
% i=120;
while flag==1 && ii<FrameEnd_Num
    ii=ii+1;
    FileName = strcat (FilePath,num2str(ii),'.bmp'); 
    temp=imread(FileName);
    %240*320将图片归一化刀240320的分辨率
    img_now=imresize(im2single(temp),[240,320]);%会导致取点不连续
%     img_now=imresize(im2single(temp),1);
    img_diff3=abs(img_now-img_past);                                        
    
    
    %mask
    FileName_mask = strcat (FilePath_mask,num2str(ii),'.bmp');
    temp_mask = imread(FileName_mask);
    img_now_mask=imresize(im2single(temp_mask),[240,320]);
    img_now_mask=im2bw(img_now_mask,0.01);     temp=img_diff3.*img_now_mask;    
    img_mask_background=1.-img_now_mask;%background_mask        
    temp2=img_diff3.*img_mask_background;  
%     img_mask_background=img_now_mask;

%     figure(111)
%     imshow(img_mask_background)


%     if sum(sum(img_diff3))==0   
%         continue
%     else
%         i=i+1;
%         ii;
%     end
    i=i+1; 
    Layer_P_num(i)=sum(sum(img_diff3>num_parament));                        Layer_P_looming_num(i)=sum(sum(temp>num_parament));     Layer_P_background_num(i)=sum(sum(temp2>num_parament));
    if  i>2 
        %-----------ALGMD-----------------
        Layer_V2=(img_diff2-conv2(img_diff1,kernel_I2,'same'));             Layer_V2_num(i)=sum(sum(Layer_V2>num_parament));
        Layer_V23=(img_diff2-conv2(img_diff1,kernel_I3,'same')); 
        Layer_V3=(img_diff3-conv2(img_diff2,kernel_I3,'same'));             Layer_V3_num(i)=sum(sum(Layer_V3>num_parament));

        %求加速度信息
        Layer_V3(Layer_V3<0.1)=0;
        Layer_temp = conv2(Layer_V3,kernel_A,'same');
        Layer_A=Layer_temp.*imbinarize(Layer_V2,0.03).*abs((imbinarize(Layer_V23,0.1)-1));  Layer_A_num(i)=sum(sum(Layer_A>num_parament));
        
        Layer_A_looming=(Layer_A.*img_now_mask);                            Layer_A_looming_num(i)=sum(sum(Layer_A_looming>num_parament));
        Layer_V2_looming=(Layer_V2.*img_now_mask);                          Layer_V2_looming_num(i)=sum(sum(Layer_V2_looming>num_parament));
        Layer_V3_looming=(Layer_V3.*img_now_mask);                          Layer_V3_looming_num(i)=sum(sum(Layer_V3_looming>num_parament));

        Layer_A_background=(Layer_A.*img_mask_background);                            Layer_A_background_num(i)=sum(sum(Layer_A_background>num_parament));
        Layer_V2_background=(Layer_V2.*img_mask_background);                          Layer_V2_background_num(i)=sum(sum(Layer_V2_background>num_parament));
        Layer_V3_background=(Layer_V3.*img_mask_background);                          Layer_V3_background_num(i)=sum(sum(Layer_V3_background>num_parament));
        
        %多版本SNR
        SNR_P(i)=Layer_A_num(i)/Layer_P_num(i);
        A_SNR_P_looming(i)=Layer_A_looming_num(i)/Layer_P_looming_num(i);
        SNR_V2(i)=Layer_A_num(i)/Layer_V2_num(i);
        SNR_V2_looming(i)=Layer_A_looming_num(i)/Layer_V2_looming_num(i);
        SNR_V3(i)=Layer_A_num(i)/Layer_V3_num(i);
        SNR_V3_looming(i)=Layer_A_looming_num(i)/Layer_V3_looming_num(i);

        A_SNR_P_background(i)=Layer_A_background_num(i)/Layer_P_background_num(i);
        SNR_V2_background(i)=Layer_A_background_num(i)/Layer_V2_background_num(i);
        SNR_V3_background(i)=Layer_A_background_num(i)/Layer_V3_background_num(i);



        figure(111)
        imshow(Layer_A)
        imwrite(Layer_A,strcat('C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\temp_algmd\',num2str(i),'.bmp'));
        title(num2str(i))
%         figure(111)
%         imshow(Layer_A_looming)
%         title(back)

% %         %计算具有速度，加速度的像素点个数
        A_num(i)=sum(sum(Layer_A>0.1));
%         A_num_background(i)=sum(sum(Layer_A_background>0.1));
        V3_num(i)=sum(sum(Layer_V3>0));
        Soma(i)=A_num(i)*V3_num(i);
        %old PDS
%         Output_temp(i)=max(0,A_num(i)-V3_num(i));    
%         Output(i)=Output_temp(i).*V3_num(i);
        %-------------------------izhikevich----------------
        k=k+1;
        [v(k),u(k)]=Izhikevich_model(v(k-1),u(k-1),Soma(i),10^-3*k/30,a,b);%v,u,I,t,a,b
        if v(k)>=30
            v(k)=c;
            u(k)=u(k-1)+d;
        end
%         终止条件和记录脉冲        
        if k>3 && v(k-1)>v(k) && v(k-1)>v(k-2) && v(k-1)>-25
            spike=spike+1;
            q(spike)=i-2;
            w(spike)=v(q(spike));
        end
        s4(i)=sum(sum(Layer_A>0));
        xxx=mapminmax(s4,0,1);
    end

    img_past=img_now;
    img_diff1=img_diff2;
    img_diff2=img_diff3;

    
end
t2 = toc;
RunTime = t2-t1
%---------spike---
figure(232323)
hold on
yyaxis left
ylabel("Number of dangerous pixel")  
% plot(V2_num,'linewidth',2)
% plot(Soma,'linewidth',2)
% plot(A_num,'linewidth',2)
% plot(V3_num)

yyaxis right
ylabel("ALGMD's neural spike")  
plot(v,'linewidth',2)
% plot(v,'linewidth',2)
plot(q(1),w(1),'rs') 
% text(q(1),w(1),['Trigger'])
% text(q(1)-40,w(1),['Trigger(' num2str(q(1)) ',' num2str(w(1)) ')'])
legend('Number of Layer A ','Neural spike','Trigger','location','NorthWest')
q(1)
% figure(110)
% hold on
% plot(far_algmd,'linewidth',2)
% % plot(eer_algmd,'linewidth',2)
% title("far and eer")
% % plot(A_num_background,'linewidth',2)
figure(6)
hold on
% plot(1:i,SNR_P)
% plot(1:i,A_SNR_P_looming)
% plot(1:i,SNR_V2)
% plot(1:i,SNR_V2_looming)
% plot(1:i,SNR_V3)
% plot(1:i,SNR_V3_looming)

plot(1:i,A_SNR_P_background)
% plot(1:i,SNR_V2)
% plot(1:i,SNR_V2_background)
% % plot(1:i,SNR_V3)
% plot(1:i,SNR_V3_background)


%------------------------------LGMD-----------------------
sigma_E = 1.5; %0.4:0.02:1; %0.4:0.02:1.5;     %distributed excitation
sigma_I = 5;%1.6:0.08:4; %1.6:0.08:6;
Max_delay =3;

a = 1.2;%1.2~1.8  
b = 4;
r = 2;
Thresh_G_0 = 0.5;
alfa = -0.1;%-0.1,-0.6;
beta = 0.5;%0.5,0.4;
lamda = 0.7;%0.7,0.6;

L2(3)=0;
B2(3)=0;
L3(3)=0;
B3(3)=0;

%****************define h(t)***************************************
x = -r:1:r;
y = -r:1:r;
for i= 1:(r*2+1)
    for j = 1:(r*2+1)
        ht(i,j)= alfa + 1./(beta+ exp(-((x(i)*lamda).^2+(y(j)*lamda).^2)));
    end
end
ht(ht<1) =0;
%***************LGMD************************************
% for k = 1:1
for k = 1:length(sigma_E)
    for h = 1:length(sigma_I)
%*********Classic LGMD **********
%     kernel_I = [0.3535 0.4472 0.5 0.4472 0.3535; 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.5 1 0 1 0.5 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.3535 0.4472 0.5 0.4472 0.3535];
    kernel_I = [0.125 0.25 0.125
                0.25 0 0.25
                0.125 0.25 0.125];
%     kernel_I = a.* kernel_I
    kernel_E = 1;       
%***************************************************
tic;
t1 = toc;
    for i=FrameSTRT_Num+Max_delay:FrameEnd_Num
        FileName = strcat (FilePath,num2str(i-3),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i-2),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame3 = imread(FileName);
        Frame3 = im2single (Frame3);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame4 = imread(FileName);
        Frame4 = im2single (Frame4);
        
        Frame_Diff1 = abs(Frame2 - Frame1);
        Frame_Diff2 = abs(Frame3 - Frame2);
        Frame_Diff3 = abs(Frame4 - Frame3);
        %mask
        FileName_mask = strcat (FilePath_mask,num2str(i),'.bmp');
        Frame_mask = imread(FileName_mask);
        Frame_mask = imresize(im2single(temp_mask),[240,320]);
        Frame_mask = im2bw(Frame_mask,0.01);%mask
        Frame_mask_background=1.-Frame_mask;%background_mask
%         Frame_mask_background=Frame_mask;


       FFI(i) = sum(sum(Frame_Diff1));
       Thresh_G(i) = FFI(k,i)*0.001/200 * Thresh_G_0;
       Thresh_G(i) = min(Thresh_G(i),0.3);
       

        Layer_E = conv2(Frame_Diff3,kernel_E,'same');
        Layer_I=conv2(Frame_Diff2,kernel_I,'same');
       Layer_S = Layer_E - Layer_I;
       Layer_S(Layer_S<0) =0;      %results will not be negative.
% %*************FFM-GD***************
        Layer_G=Layer_S;
        Layer_G_background=Layer_G.*Frame_mask_background;
        Layer_G_looming=Layer_G.*Frame_mask;

        Layer_G_num(i)=sum(sum(Layer_G>0.1));
        Layer_G_num_background(i)=sum(sum(Layer_G_background>0.1));
        Layer_G_num_looming(i)=sum(sum(Layer_G_looming>0.1));

%         L2(i)=sum(Layer_G_num);
%         B2(i)=sum(Layer_G_num_background);
        eer_lgmd(i)=Layer_G_num_looming(i)/Layer_G_num(i);
        far_lgmd(i)=1-eer_lgmd(i);
        

        LGMD_OutputS(k,i) = sum(sum(Layer_S));    %**output of G or S layer***
        LGMD_OutputG(k,i) = sum(sum(Layer_G));    %**output of G or S layer***
%         figure(123)
%         imshow(Layer_G_background)

%    figure(1)
%    Video_Resize = imresize(Layer_G,0.5);
%    imshow(Video_Resize);
    end
    %*************************************************
    Normalized_OutS(k,1:i) = mapminmax(LGMD_OutputS(k,:), 0, 1);
    Normalized_OutG(k,1:i) = mapminmax(LGMD_OutputG(k,:), 0, 1);
%     G_max=max(LGMD_OutputG);
%     Normalized_OutG(k,1:i)=normal(G_max,1,LGMD_OutputG(k,:));
    end
end
t2 = toc;
RunTime = t2-t1

% figure(110)
% hold on
% plot(far_lgmd,'linewidth',2)
% plot(eer_lgmd,'linewidth',2)
%--------------------------------------------------------------------------------------------------DLGMD-------------------------------------
sigma_E = 1.5; %0.4:0.02:1; %0.4:0.02:1.5;     %distributed excitation
sigma_I = 5;%1.6:0.08:4; %1.6:0.08:6;

Max_delay = 3;
LGMD_OutputS = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
FFI = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
Threshold_Pnt = zeros(length(sigma_E),1);
kernalG = ones(4,4);

a = 1.2;%1.2~1.8  %第二次实验a=1
% a=0.8;
b = 4;
r = 2;
Thresh_G_0 = 0.5;
alfa = -0.1;%-0.1,-0.6;
beta = 0.5;%0.5,0.4;
lamda = 0.7;%0.7,0.6;
%****************define h(t)***************************************
x = -r:1:r;
y = -r:1:r;
for i= 1:(r*2+1)
    for j = 1:(r*2+1)
        ht(i,j)= alfa + 1./(beta+ exp(-((x(i)*lamda).^2+(y(j)*lamda).^2)));
    end
end
ht(ht<1) =0;
%***************D-LGMD************************************
% for k = 1:1
for k = 1:length(sigma_E)
    for h = 1:length(sigma_I)
%*********Classic LGMD **********
%     kernel_I = [0.3535 0.4472 0.5 0.4472 0.3535; 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.5 1 0 1 0.5 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.3535 0.4472 0.5 0.4472 0.3535];
% %     kernel_I = [0.125 0.25 0.125
% %                 0.25 0 0.25
% %                 0.125 0.25 0.125];
    %     kernel_I = a.* kernel_I
%     kernel_E = 1;       
%**********distributed excitation and inhibition kernels***********    
    Tempkernel = DOGAnalysis(a, sigma_I(h)/sigma_E(k) , sigma_E(k), r ,k);  %Func(a,b,sigma,r);
    kernel_E = GaussAnalysis(sigma_E(k),r);
    kernel_E(ht<1) = Tempkernel(ht<1);   %To form distributed time delay, which is determined by the h(t) distribution.(Self-inhibition involved here)
    
    kernel_E(ht>1) = 0;
    kernel_E(kernel_E<0) = 0;
    Showkerne_E = round (kernel_E*100);

    kernel_I = a * GaussAnalysis(sigma_I(h),r);
    kernel_I(ht<1) =0;%(here I make the h(t) distribution in this principle: delay=0 when ht<1, otherwise delay=1)
    kernel_I_delay1 = kernel_I;

    kernel_I_delay1(ht<1) =0;
    kernel_I_delay1(ht>1.8999) =0;
    Showkernel_I_delay1 = round (kernel_I_delay1*100);
    
    kernel_I_delay2 = kernel_I;
    kernel_I_delay2(ht<1.8999) =0;
    Showkernel_I_delay2 = round (kernel_I_delay2*100);
%***************************************************
tic;
t1 = toc;
    for i=FrameSTRT_Num+Max_delay:FrameEnd_Num
        FileName = strcat (FilePath,num2str(i-3),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i-2),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame3 = imread(FileName);
        Frame3 = im2single (Frame3);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame4 = imread(FileName);
        Frame4 = im2single (Frame4);
        
        Frame_Diff1 = abs(Frame2 - Frame1);
        Frame_Diff2 = abs(Frame3 - Frame2);
        Frame_Diff3 = abs(Frame4 - Frame3);
        %mask
        FileName_mask = strcat (FilePath_mask,num2str(i),'.bmp');
        Frame_mask = imread(FileName_mask);
        Frame_mask = imresize(im2single(temp_mask),[240,320]);
        Frame_mask = im2bw(Frame_mask,0.01);%mask
        Frame_mask_background=1.-Frame_mask;%background_mask
%         Frame_mask_background=Frame_mask;
        Layer_P_num(i)=sum(sum(Frame_Diff3>num_parament));       temp=Frame_Diff3.*Frame_mask;       Layer_P_looming_num(i)=sum(sum(temp>num_parament));
        temp2=Frame_Diff3.*Frame_mask_background;       Layer_P_background_num(i)=sum(sum(temp2>num_parament));

       FFI(i) = sum(sum(Frame_Diff1));
       Thresh_G(i) = FFI(k,i)*0.001/200 * Thresh_G_0;
       Thresh_G(i) = min(Thresh_G(i),0.3);
       
%       (Note: Layer_I = currentframe (conv) kernel_I_delay0 + delayed_1frame (conv)
%       kernel_I_delay1 +delayed_2frame (conv) kernel_I_delay2)
        Layer_E = conv2(Frame_Diff3,kernel_E,'same');
        Layer_I_delay1 = conv2(Frame_Diff2,kernel_I_delay1,'same');
        Layer_I_delay2 = conv2(Frame_Diff1,kernel_I_delay2,'same');
        Layer_I = Layer_I_delay1 + Layer_I_delay2;  %delay0 has been involved to kernal E.
        
       Layer_S = Layer_E - Layer_I;
       Layer_S(Layer_S<0) =0;      %results will not be negative.
       
       sum_p=sum(sum(Frame_Diff3));
        sum_s=sum(sum(Layer_S));
%         PS=sum_s/sum_p;
% %*************FFM-GD***************
       Layer_G_Cef = conv2(Layer_S,kernalG,'same');
       Layer_G =Layer_S .* Layer_G_Cef;
%        Layer_G=Layer_S;

        Layer_G(Layer_G<Thresh_G(i))=0;%change yuzhi
        Layer_G(Layer_G>1)=1;


        Layer_S_num(i)=sum(sum(Layer_S>num_parament));
        Layer_G_num(i)=sum(sum(Layer_G>num_parament));
        Layer_G_looming=Layer_G.*Frame_mask;
        Layer_S_looming=Layer_S.*Frame_mask;
        Layer_G_looming=(Layer_G.*img_now_mask);                            Layer_G_looming_num(i)=sum(sum(Layer_G_looming>num_parament));
        Layer_G_background=(Layer_G.*Frame_mask_background);                            Layer_G_background_num(i)=sum(sum(Layer_G_background>num_parament));
        Layer_S_looming=(Layer_S.*img_now_mask);                          Layer_S_looming_num(i)=sum(sum(Layer_S_looming>num_parament));
        %多版本SNR
        SNR_P(i)=Layer_G_num(i)/Layer_P_num(i);
        D_SNR_P_looming(i)=Layer_G_looming_num(i)/Layer_P_looming_num(i);
        SNR_S(i)=Layer_G_num(i)/Layer_S_num(i);
        SNR_S_looming(i)=Layer_G_looming_num(i)/Layer_S_looming_num(i);

        D_SNR_P_background(i)=Layer_G_background_num(i)/Layer_P_background_num(i);



%         Layer_G(Layer_G<0.7)=0;
%          LGMD_OutputPS(k,i) = PS;
        Layer_G_background=Layer_G.*Frame_mask_background;
        Layer_G_looming=Layer_G.*Frame_mask;
%         imwrite(Layer_G,strcat('C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\temp_dlgmd\',num2str(i),'.bmp'));

%         figure(1)
%         imshow(Layer_G_looming)

        Layer_G_num(i)=sum(sum(Layer_G>0.1));
        Layer_G_num_background(i)=sum(sum(Layer_G_background>0.1));
        Layer_G_num_looming(i)=sum(sum(Layer_G_looming>0.1));

%         L3(i)=sum(Layer_G_num);
%         B3(i)=sum(Layer_G_num_background);
        eer_dlgmd(i)=Layer_G_num_looming(i)/Layer_G_num(i);
        far_dlgmd(i)=Layer_G_num_background(i)/Layer_G_num(i);

        P_num(i)=sum(sum(Frame_Diff3>0.1));

        Attention_DLGMD(i)=Layer_G_num(i)/P_num(i);



        LGMD_OutputS(k,i) = sum(sum(Layer_S));    %**output of G or S layer***
        LGMD_OutputG(k,i) = sum(sum(Layer_G));    %**output of G or S layer***
%         LGMD_OutputG(k,i) = sum(sum(Layer_G~=0)); 
%         imwrite(Layer_G,strcat('C:\Users\Administrator\Desktop\acc\论文撰写\figures\68\imwrite\',num2str(i),'.bmp'));

%    figure(1)
%    Video_Resize = imresize(Layer_G,1);
%    imshow(Video_Resize);
%    title(strcat('G',num2str(i)));
    end
    %*************************************************
    Normalized_OutS(k,1:i) = mapminmax(LGMD_OutputS(k,:), 0, 1);
    DNormalized_OutG(k,1:i) = mapminmax(LGMD_OutputG(k,:), 0, 1);
%     Normalized_OutPS(k,1:i) = mapminmax(LGMD_OutputPS(k,:), 0, 1);


%         G_max=max(LGMD_OutputG);
%     Normalized_OutG(k,1:i)=normal(G_max,1,LGMD_OutputG(k,:));
    end
end
t2 = toc;
RunTime_LGMD = t2-t1

% figure(110)
% hold on
% plot(far_dlgmd,'linewidth',2)
% % plot(eer_dlgmd,'linewidth',2)
% % legend("ALGMD-far","ALGMD-eer","LGMD-far","LGMD-eer","DLGMD-far","DLGMD-eer")
% legend("ALGMD-eer","LGMD-eer","DLGMD-eer")

% plot(Layer_G_num_background,'linewidth',2)
% figure(111)
% hold on
% plot(B,'linewidth',2)
% plot(B2,'linewidth',2)
% plot(B3,'linewidth',2)
% legend("ALGMD","DLGMD","LGMD")


% figure(6)
% hold on
% % plot(1:i,SNR_P)
% % plot(1:i,D_SNR_P_looming)
% plot(1:i,D_SNR_P_background)

% plot(1:i,SNR_S)
% plot(1:i,SNR_S_looming)



%----------------------------------------------------
%---------------------------------------------------------OppLoD---------------------------------------------------------------------------------
%****************Claimed Parameters********************************
sigma_E = 1.5; %0.4:0.02:1; %0.4:0.02:1.5;     %distributed excitation
sigma_I = 5; %1.6:0.08:4; %1.6:0.08:6;
Max_delay = 3;
LGMD_OutputS = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
FFI = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
Threshold_Pnt = zeros(length(sigma_E),1);
kernalG = ones(4,4);

a = 1.5; %1.2~1.8  
% b = 4;
r =2;
Thresh_G_0 = 0.5;
alfa = -0.1; %-0.1,-0.6;
beta = 0.5; %0.5,0.4;
lamda = 0.7; %0.7,0.6;
%****************define h(t)***************************************
x = -r:1:r;
y = -r:1:r;
for i= 1:(r*2+1)
    for j = 1:(r*2+1)
        ht(i,j)= alfa + 1./(beta+ exp(-((x(i)*lamda).^2+(y(j)*lamda).^2)));
    end
end
ht(ht<1) =0;
data = zeros(FrameEnd_Num-FrameSTRT_Num-Max_delay-1,1);
%***************D-LGMD************************************
% for k = 1:1
for k = 1:length(sigma_E)
    for h = 1:length(sigma_I)
%*********Classic LGMD ***********************************
%     kernel_I = [0.3535 0.4472 0.5 0.4472 0.3535; 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.5 1 0 1 0.5 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.3535 0.4472 0.5 0.4472 0.3535];
% %     kernel_I = [0.125 0.25 0.125
% %                 0.25 0 0.25
% %                 0.125 0.25 0.125];
%     kernel_I = a.* kernel_I
%     kernel_E = 1; 

%*****************form a 13*13 mat*********************************
B=[]; % distributed triu,225'
for i =1:2*r+1 % ori:13, plot:51
    for j=1:2*r+1
        if i<=j
            B(i,j)=(2*r+1-j+i)/10; %(13-j+i)/10;(j-i)/10
        else
            B(i,j)=0;
        end
    end
end

% B = A; % down
B_l = rot90(B,2); % 45', up
C = rot90(B,1); % -45', right
C_l = rot90(C,2); % 135',left
%******************************************************************
%**********distributed excitation and inhibition kernels***********    
    Tempkernel = DOGAnalysis(a, sigma_I(h)/sigma_E(k) , sigma_E(k), r ,k);  %Func(a,b,sigma,r);
    kernel_E = GaussAnalysis(sigma_E(k),r);
    kernel_E(ht<1) = Tempkernel(ht<1);   %To form distributed time delay, which is determined by the h(t) distribution.(Self-inhibition involved here)
    kernel_E(ht>1) = 0;
    kernel_E(kernel_E<0) = 0;
    Showkerne_E = round (kernel_E*100);

    kernel_I = a * GaussAnalysis(sigma_I(h),r);
    kernel_I(ht<1) =0; %(here I make the h(t) distribution in this principle: delay=0 when ht<1, otherwise delay=1)
    kernel_I_delay1 = kernel_I;

    kernel_I_delay1(ht<1) =0;
    kernel_I_delay1(ht>1.8999) =0;
    Showkernel_I_delay1 = round (kernel_I_delay1*100);
    % modified kernel_I
    kernel_I_delay1_B_u = kernel_I_delay1.*B; % 225',.*Sigmoid(270, x, y)
    kernel_I_delay1_B_l = kernel_I_delay1.*B_l; % 45',.*Sigmoid(90, x, y)
    kernel_I_delay1_C_u = kernel_I_delay1.*C; % -45',.*Sigmoid(180, x, y)
    kernel_I_delay1_C_l = kernel_I_delay1.*C_l; % 135',.*Sigmoid(0, x, y)
    
    kernel_I_delay2 = kernel_I;
    kernel_I_delay2(ht<1.8999) =0;
    Showkernel_I_delay2 = round (kernel_I_delay2*100);
    kernel_I_delay2_B_u = kernel_I_delay2.*B; %.*Sigmoid(270, x, y)
    kernel_I_delay2_B_l = kernel_I_delay2.*B_l; %.*Sigmoid(90, x, y)
    kernel_I_delay2_C_u = kernel_I_delay2.*C; % .*Sigmoid(180, x, y)
    kernel_I_delay2_C_l = kernel_I_delay2.*C_l; % .*Sigmoid(0, x, y)
%*****************************************************  
%*****************************************************
tic;
t1 = toc;
    for i=FrameSTRT_Num+Max_delay:FrameEnd_Num
        FileName = strcat (FilePath,num2str(i-3),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i-2),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame3 = imread(FileName);
        Frame3 = im2single (Frame3);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame4 = imread(FileName);
        Frame4 = im2single (Frame4);
        
        Frame_Diff1 = abs(Frame2 - Frame1);
        Frame_Diff2 = abs(Frame3 - Frame2);
        Frame_Diff3 = abs(Frame4 - Frame3);
        
        FFI(i) = sum(sum(Frame_Diff1));
        Thresh_G(i) = FFI(k,i)*0.001/200 * Thresh_G_0;
        Thresh_G(i) = min(Thresh_G(i),0.3);
       
%       (Note: Layer_I = currentframe (conv) kernel_I_delay0 + delayed_1frame (conv)
%       kernel_I_delay1 +delayed_2frame (conv) kernel_I_delay2)
        Layer_E = conv2(Frame_Diff3,kernel_E,'same');
        Layer_I_delay1_B_u = conv2(Frame_Diff2,kernel_I_delay1_B_u,'same');
        Layer_I_delay1_B_l = conv2(Frame_Diff2,kernel_I_delay1_B_l,'same');
        Layer_I_delay1_C_u = conv2(Frame_Diff2,kernel_I_delay1_C_u,'same');
        Layer_I_delay1_C_l = conv2(Frame_Diff2,kernel_I_delay1_C_l,'same');
        
        Layer_I_delay2_B_u = conv2(Frame_Diff1,kernel_I_delay2_B_u,'same');
        Layer_I_delay2_B_l = conv2(Frame_Diff1,kernel_I_delay2_B_l,'same');
        Layer_I_delay2_C_u = conv2(Frame_Diff1,kernel_I_delay2_C_u,'same');
        Layer_I_delay2_C_l = conv2(Frame_Diff1,kernel_I_delay2_C_l,'same');
        
        Layer_I_B_u = Layer_I_delay1_B_u + Layer_I_delay2_B_u;  %delay0 has been involved to kernal E.
        Layer_I_B_l = Layer_I_delay1_B_l + Layer_I_delay2_B_l;
        Layer_I_C_u = Layer_I_delay1_C_u + Layer_I_delay2_C_u;  
        Layer_I_C_l = Layer_I_delay1_C_l + Layer_I_delay2_C_l;
        
        Layer_S_B_u = Layer_E - Layer_I_B_u;
        Layer_S_B_l = Layer_E - Layer_I_B_l;
        Layer_S_C_u = Layer_E - Layer_I_C_u;
        Layer_S_C_l = Layer_E - Layer_I_C_l;
       
%        imwrite(Layer_S_B_u,strcat('F:\code\gu_-drone\D-LGMD (Matlab)\results\Layer_S_B_u_chair\',num2str(i),'.bmp'));
%*****************************sliding window*******************************
       [wid,ht] = size(Layer_S_B_u); % chair,540*960
       % the results are related to the size of bbox 
%        240 320 80 80
       win_w =80; % round(w/5);181,300,400
       win_h = 80; % round(h/5);181,300,400
       win_step = 50; % 50;100
       %960 540  忘记了
%        win_w = 300; % round(w/5);181,300,400
%        win_h = 300; % round(h/5);181,300,400
%        win_step = 100; % 50;100

       i_all = [];
       j_all = [];
       for m = 1:win_step:(wid-win_w)
           for n = 1:win_step:(ht-win_h)    
               temp_img_B_u = Layer_S_B_u(m:m+win_w-1, n:n+win_h-1, :); % acquire bbox 
               temp_img_B_l = Layer_S_B_l(m:m+win_w-1, n:n+win_h-1, :);
               temp_img_C_u = Layer_S_C_u(m:m+win_w-1, n:n+win_h-1, :); 
               temp_img_C_l = Layer_S_C_l(m:m+win_w-1, n:n+win_h-1, :);
               
               temp_img_B_u(temp_img_B_u<0) =0;      
               temp_img_B_l(temp_img_B_l<0) =0;
               temp_img_C_u(temp_img_C_u<0) =0;      
               temp_img_C_l(temp_img_C_l<0) =0;
               
               temp_Layer_S_B_u_r = rot90(temp_img_B_u,2);
               temp_S1 = temp_Layer_S_B_u_r.*temp_img_B_l; % downleft
               temp_Layer_S_B_l_r = rot90(temp_img_B_l,2);
               temp_S2 = temp_Layer_S_B_l_r.*temp_img_B_u; % upright
               temp_S12 = temp_S1 + temp_S2; % the symmetric area,1/3 quadrant 
               temp_Layer_S_C_u_r = rot90(temp_img_C_u,2);
               temp_S3 = temp_Layer_S_C_u_r.*temp_img_C_l; % downright
               temp_Layer_S_C_l_r = rot90(temp_img_C_l,2);
               temp_S4 = temp_Layer_S_C_l_r.*temp_img_C_u; % upleft
               temp_S34 = temp_S3 + temp_S4; % the symmetric area,2/4 quadrant
               temp_S12_r = rot90(temp_S12,1);
               temp_S = temp_S1 + temp_S2 + temp_S3 + temp_S4; % 2 opposite angles
%                temp_S = temp_S12_r.*temp_S34;
               
               % select the bbox
               temp_sum_S = sum(sum(temp_S));
               if temp_sum_S>1 % the threshold; 0.05,0.01
                  % select the symmetric pixels
                   data = temp_S;
%                    [row,column] = find(data==max(max(data))); % location of the max pixel
%                    data_max = max(max(data))
                   temp_data_max = max(max(temp_S));
                   [row,column] = find(data>=temp_data_max*0.3 & data<=temp_data_max);
                   temp_i = row+m;
                   i_all = vertcat(i_all,temp_i);  
                   temp_j = column+n;
                   j_all = vertcat(j_all,temp_j); % locations of each frame
               end        
%                imwrite(tmp_img_u,strcat('F:\code\gu_-drone\D-LGMD (Matlab)\dataset\slidewindow_tmpimg_u\',num2str(i),'_',num2str(m),'_',num2str(n),'.bmp'));            
%                figure(1);
%                imshow(temp_S);
%                title(strcat(num2str(i),'\_',num2str(m),'\_',num2str(n)));
           end
       end 
       temp_sum_S_max(i) = max(max(temp_sum_S)); % plot
%**************************************************************************         
%***********************original Layer_S***********************************
       Layer_I_delay1 = conv2(Frame_Diff2,kernel_I_delay1,'same');
       Layer_I_delay2 = conv2(Frame_Diff1,kernel_I_delay2,'same');
       Layer_I = Layer_I_delay1 + Layer_I_delay2;  %delay0 has been involved to kernal E.
       Layer_S = Layer_E - Layer_I;
       Layer_S(Layer_S<0) =0;
%*********************enhance Layer_S**************************************
       Layer_S_enhancement = Layer_S;    
       for i_idx = 1:length(i_all)
%            Layer_S_enhancement(i_all(i_idx),j_all(i_idx)) = Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*100;
%            Layer_S_enhancement(i_all(i_idx),j_all(i_idx)) = Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*Layer_S(i_all(i_idx),j_all(i_idx)).*50;
           Layer_S_enhancement(i_all(i_idx),j_all(i_idx)) = Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*Layer_S(i_all(i_idx),j_all(i_idx));

       end
%         figure(6)         
%         imshow(Layer_S_enhancement);   
%         title([num2str(i),'th Frame']);
%**********************************************
% %*************FFM-GD*************************
       Layer_G_Cef = conv2(Layer_S,kernalG,'same');
       Layer_G = Layer_S .* Layer_G_Cef;
       Layer_G(Layer_G<Thresh_G(i))=0; %Thresh_G(i)
       Layer_G(Layer_G>1)=1;
        
       P_num_LGMD=sum(sum(Frame_Diff3>0.1));
       Oplod_num=sum(sum(Layer_G>0.1));
       Sensitivity_opplod(i)=Oplod_num/P_num_LGMD;


        
       LGMD_OutputS(k,i) = sum(sum(Layer_S));    %**output of G or S layer
       LGMD_OutputG(k,i) = sum(sum(Layer_G));    %**output of G or S layer
       LGMD_Outputsum_S(k,i) = sum(sum(Layer_S_enhancement)); 
    
    end
    Normalized_OutS(k,1:i) = mapminmax(LGMD_OutputS(k,:), 0, 1);
%     Normalized_OutG(k,1:i) = mapminmax(LGMD_OutputG(k,:), 0, 1);
    Oppnency_output(k,1:i) = mapminmax(LGMD_Outputsum_S(k,:), 0, 1);
    end
end
t2 = toc;
RunTime2 = t2-t1
%---------------------------------------------------------Oppnency---------------------------------------------------------------------------------



%--------计算attc和far-------------
% figure(1)
% hold on
% plot(1:FrameEnd_Num,xxx,'linewidth',2,'linestyle','-')
% for k = 1:length(sigma_E)
%     figure (1)
%     hold on
% %     plot (1:i,Normalized_OutS(k,(1:i)));
%     plot (1:i,Normalized_OutG(k,(1:i)),'linewidth',2,'linestyle','-');
%     plot (1:i,DNormalized_OutG(k,(1:i)),'linewidth',2,'linestyle','-');
%     xlabel('Frames');
%     ylabel('Normalised Output');
%     legend('ALGMD','LGMD','DLGMD',Location='northwest')
%     title("Normalised Output")
% end


% figure(2)
% hold on
% title("far")
% plot(1:FrameEnd_Num,far_algmd,'linewidth',2,'linestyle','-')
% % plot(1:FrameEnd_Num,far_dlgmd,'linewidth',2,'linestyle','-')
% % plot(1:FrameEnd_Num,far_lgmd,'linewidth',2,'linestyle','-')
% 
% figure(3)
% hold on
% title("eer")
% plot(1:FrameEnd_Num,eer_algmd,'linewidth',2,'linestyle','-')
% % plot(trigger_algmd,eer_algmd(trigger_algmd),'rs') 
% plot(1:FrameEnd_Num,eer_dlgmd,'linewidth',2,'linestyle','-')
% % plot(1:FrameEnd_Num,eer_lgmd,'linewidth',2,'linestyle','-')

figure(4)
hold on
% title("Sensitivity")
title("False detection rate")
plot(1:FrameEnd_Num,A_SNR_P_background,'linewidth',2,'linestyle','-')
% plot(trigger_algmd,A_SNR_P_looming(trigger_algmd),'rs') 
plot(1:FrameEnd_Num,D_SNR_P_background,'linewidth',2,'linestyle','-')
% % plot(1:FrameEnd_Num,Sensitivity_opplod,'linewidth',2,'linestyle','-')
% 
xlabel('Frames');
ylabel('Output/Input');
% legend('ALGMD-chair','DLGMD-chair','ALGMD-QRcode','DLGMD-QRcode',Location='northwest')
legend('ALGMD-BasketballStand','DLGMD-BasketballStand','ALGMD-Uav','DLGMD-Uav',Location='northwest')
% plot(trigger_algmd,attention(trigger_algmd),'rs') 
%---------ATTC--------
% trigger_algmd=find(xxx>0.3,1)
trigger_lgmd=find(Normalized_OutG>0.3,1)
trigger_dlgmd=find(DNormalized_OutG>0.3,1)


ATTC_ALGMD=0.03*(FrameEnd_Num-find(xxx>0.3,1));
ATTC_LGMD=0.03*(FrameEnd_Num-find(Normalized_OutG>0.3,1));
ATTC_DLGMD=0.03*(FrameEnd_Num-find(DNormalized_OutG>0.3,1));



% 100*calculateAverage(far_lgmd,trigger_lgmd)
% 100*calculateAverage(far_dlgmd,trigger_dlgmd)
% 100*calculateAverage(far_algmd,trigger_algmd)
100*calculateAverage(A_SNR_P_looming,trigger_algmd)
100*calculateAverage(D_SNR_P_looming,trigger_dlgmd)

