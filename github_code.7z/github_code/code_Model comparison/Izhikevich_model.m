function [vf,uf] = Izhikevich_model(v,u,I,t,a,b)
    v1 = 0.04.*v.*v+5.*v+140-u+I;
    u1 = a.*(b.*v-u);
    
    vf=v+t.*v1;
    uf=u+t.*u1;
end