% clear;clc;
FrameSTRT_Num =1; 
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\box\';FrameEnd_Num =33;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\ball\';FrameEnd_Num =37;

% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\chair\';FrameEnd_Num =120;
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\chair\';FrameEnd_Num =120;
    FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\QRcode_0.5\';FrameEnd_Num =134;

% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV3_movingcar\';FrameEnd_Num =32;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV2_basketballstick\';FrameEnd_Num =54;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV4_uav\';FrameEnd_Num =42;
for rrr=1 :1
% % % % ---------------------------------------------------------Optical_DVS---------------------------------------------------------------------------------
% load('C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\code_five model\box.mat');%1280x800
% load('C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\code_five model\ball.mat');%1280x800
% wide  = 1282;
% high = 802;
% layer = zeros(wide,high);
% pic= zeros(wide,high);
% % events = table2struct(data_events);+
% img_count = 1;
% v=[[1,0];
% [1,1]; 
% [0,1];
% [-1,1];
% [-1,0];
% [-1,-1];
% [0,-1];
% [1,-1];];
% 
% x(wide,high).t=0;
% x(wide,high).p=0;
% x(wide,high).vx= 0;
% x(wide,high).vy= 0;
% 
% timer_start =  DVS0003.t(1);
% 
% % get_num = strcat('num = height(',val_name,');');
% % eval(get_num);
% 
% %box
% num = height(DVS0003);
% % num = 1688767;
% kernel_optical=0.00125*[1 1 1
%     1 0 1
%     1 1 1];
% j=0;
% 
% %% do it now
% tic;
% t1 = toc;
% for i = 1:num
%     event.x = DVS0003.x(i);
%     event.y = DVS0003.y(i);
%     event.t = DVS0003.t(i);
%     %ball 无极性
%     event.p = DVS0003.p(i);
%     xx=2+event.x;
%     yy=2+event.y;
%     x(xx,yy).t=event.t;
%     %ball 无极性
%     x(xx,yy).p=event.p;
% %伪帧
%     timer_1 = event.t - timer_start;
% %     BOX 伪帧长度43421    ball 56738
% %     if timer_1 < 43421
%     if timer_1 < 56738
%             pic_vx=0;
%             pic_vy=0;
%         for k=1:8
%             xxx=xx+v(k,1);
%             yyy=yy+v(k,2);
% 
%             ABS=abs(x(xxx,yyy).t - event.t)<1001;
%             %ball 无极性
%             PP=(x(xxx, yyy).p == event.p);
% %                 if ABS
%                 if ABS & PP
% %                     x(xx,yy).vx=x(xx,yy).vx+v(k,1);
% %                     x(xx,yy).vy=x(xx,yy).vy+v(k,2);
%                       pic_vx=pic_vx+v(k,1);
%                       pic_vy=pic_vy+v(k,2);
%                 end
%         end
%         pic(xx,yy)=50*(pic_vx*pic_vx+pic_vy*pic_vy);
% 
%     else
% 
%         %-------------------------------------
%         img_show = uint8(pic);
%         img_show=conv2(img_show,kernel_optical,"same");
%         j=j+1;
%         S(j)=(sum(sum(img_show)));
% 
% %         figure(1);
% %         img_show = imresize(img_show,1);
% %         img_show = imrotate(img_show,90);
% %         imshow(img_show);
% %         imwrite(img_show,strcat('C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\code_five model\ball_pic\pic_',num2str(img_count),'.bmp'));
%         img_count = img_count +1;
%         layer = zeros(wide,high);
%         timer_start = event.t;
%         pic= zeros(wide,high);
%         if j==FrameEnd_Num
%             break
%         end
%     end
% end
% 
% t2 = toc;
% RunTime0(rrr) = t2-t1
% % Max=max(S);
% % S(j)=mapminmax;
% Optical_DVS_output = mapminmax(S,0, 1);
% figure (10)
%     hold on
% plot (1:FrameEnd_Num,Optical_DVS_output(1:FrameEnd_Num),'linewidth',2,'linestyle','-')
% % ---------------------------------------------------------Optical_DVS---------------------------------------------------------------------------------
%---------------------------------------------------------D-LGMD-----------------------------------------------------------------------------------
%**************Claimed Parameters********************************
sigma_E = 1.5; %0.4:0.02:1; %0.4:0.02:1.5;     %distributed excitation
sigma_I = 5;%1.6:0.08:4; %1.6:0.08:6;
Max_delay = 3;
LGMD_OutputS = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
FFI = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
Threshold_Pnt = zeros(length(sigma_E),1);
kernalG = ones(4,4);

a = 1.2;%1.2~1.8  
b = 4;
r = 2;
Thresh_G_0 = 0.5;
alfa = -0.1;%-0.1,-0.6;
beta = 0.5;%0.5,0.4;
lamda = 0.7;%0.7,0.6;
%****************define h(t)***************************************
x = -r:1:r;
y = -r:1:r;
for i= 1:(r*2+1)
    for j = 1:(r*2+1)
        ht(i,j)= alfa + 1./(beta+ exp(-((x(i)*lamda).^2+(y(j)*lamda).^2)));
    end
end
ht(ht<1) =0;
%***************D-LGMD************************************
% for k = 1:1
for k = 1:length(sigma_E)
    for h = 1:length(sigma_I)
%*********Classic LGMD **********
%     kernel_I = [0.3535 0.4472 0.5 0.4472 0.3535; 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.5 1 0 1 0.5 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.3535 0.4472 0.5 0.4472 0.3535];
% %     kernel_I = [0.125 0.25 0.125
% %                 0.25 0 0.25
% %                 0.125 0.25 0.125];
    %     kernel_I = a.* kernel_I
%     kernel_E = 1;       
%**********distributed excitation and inhibition kernels***********    
    Tempkernel = DOGAnalysis(a, sigma_I(h)/sigma_E(k) , sigma_E(k), r ,k);  %Func(a,b,sigma,r);
    kernel_E = GaussAnalysis(sigma_E(k),r);
    kernel_E(ht<1) = Tempkernel(ht<1);   %To form distributed time delay, which is determined by the h(t) distribution.(Self-inhibition involved here)
    kernel_E(ht>1) = 0;
    kernel_E(kernel_E<0) = 0;
    Showkerne_E = round (kernel_E*100);

    kernel_I = a * GaussAnalysis(sigma_I(h),r);
    kernel_I(ht<1) =0;%(here I make the h(t) distribution in this principle: delay=0 when ht<1, otherwise delay=1)
    kernel_I_delay1 = kernel_I;

    kernel_I_delay1(ht<1) =0;
    kernel_I_delay1(ht>1.8999) =0;
    Showkernel_I_delay1 = round (kernel_I_delay1*100);
    
    kernel_I_delay2 = kernel_I;
    kernel_I_delay2(ht<1.8999) =0;
    Showkernel_I_delay2 = round (kernel_I_delay2*100);
%***************************************************
tic;
t1 = toc;
    for i=FrameSTRT_Num+Max_delay:FrameEnd_Num
        FileName = strcat (FilePath,num2str(i-3),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i-2),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame3 = imread(FileName);
        Frame3 = im2single (Frame3);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame4 = imread(FileName);
        Frame4 = im2single (Frame4);
        
        Frame_Diff1 = abs(Frame2 - Frame1);
        Frame_Diff2 = abs(Frame3 - Frame2);
        Frame_Diff3 = abs(Frame4 - Frame3);

       FFI(i) = sum(sum(Frame_Diff1));
       Thresh_G(i) = FFI(k,i)*0.001/200 * Thresh_G_0;
       Thresh_G(i) = min(Thresh_G(i),0.3);
       
%       (Note: Layer_I = currentframe (conv) kernel_I_delay0 + delayed_1frame (conv)
%       kernel_I_delay1 +delayed_2frame (conv) kernel_I_delay2)
        Layer_E = conv2(Frame_Diff3,kernel_E,'same');
        Layer_I_delay1 = conv2(Frame_Diff2,kernel_I_delay1,'same');
        Layer_I_delay2 = conv2(Frame_Diff1,kernel_I_delay2,'same');
        Layer_I = Layer_I_delay1 + Layer_I_delay2;  %delay0 has been involved to kernal E.
        
       Layer_S = Layer_E - Layer_I;
       Layer_S(Layer_S<0) =0;      %results will not be negative.
       
       sum_p=sum(sum(Frame_Diff3));
        sum_s=sum(sum(Layer_S));
%         PS=sum_s/sum_p;
% %*************FFM-GD***************
       Layer_G_Cef = conv2(Layer_S,kernalG,'same');
       Layer_G = Layer_S .* Layer_G_Cef;

        Layer_G(Layer_G<Thresh_G(i))=0;%change yuzhi
        Layer_G(Layer_G>1)=1;

        LGMD_OutputS(k,i) = sum(sum(Layer_S));    %**output of G or S layer***
        LGMD_OutputG(k,i) = sum(sum(Layer_G));    %**output of G or S layer***
%         imwrite(Layer_G,strcat('C:\Users\Administrator\Desktop\acc\论文撰写\figures\68\imwrite\',num2str(i),'.bmp'));

%         figure(1)
%         Video_Resize = imresize(Layer_G,1);
%         imshow(Video_Resize);
%    title(strcat('G',num2str(i)));
    end
    t2 = toc;
    RunTime1(rrr) = t2-t1
    %*************************************************
    Normalized_OutS(k,1:i) = mapminmax(LGMD_OutputS(k,:), 0, 1);
    D_LGMD_output(k,1:i) = mapminmax(LGMD_OutputG(k,:), 0, 1);
    end
end


%---------------------------------------------------------D-LGMD-----------------------------------------------------------------------------------
%---------------------------------------------------------OppLoD---------------------------------------------------------------------------------
%****************Claimed Parameters********************************
sigma_E = 1.5; %0.4:0.02:1; %0.4:0.02:1.5;     %distributed excitation
sigma_I = 5; %1.6:0.08:4; %1.6:0.08:6;
Max_delay = 3;
LGMD_OutputS = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
FFI = zeros(length(sigma_E),FrameEnd_Num-Max_delay-1);
Threshold_Pnt = zeros(length(sigma_E),1);
kernalG = ones(4,4);

a = 1.5; %1.2~1.8  
% b = 4;
r =2;
Thresh_G_0 = 0.5;
alfa = -0.1; %-0.1,-0.6;
beta = 0.5; %0.5,0.4;
lamda = 0.7; %0.7,0.6;
%****************define h(t)***************************************
x = -r:1:r;
y = -r:1:r;
for i= 1:(r*2+1)
    for j = 1:(r*2+1)
        ht(i,j)= alfa + 1./(beta+ exp(-((x(i)*lamda).^2+(y(j)*lamda).^2)));
    end
end
ht(ht<1) =0;
data = zeros(FrameEnd_Num-FrameSTRT_Num-Max_delay-1,1);
%***************D-LGMD************************************
% for k = 1:1
for k = 1:length(sigma_E)
    for h = 1:length(sigma_I)
%*********Classic LGMD ***********************************
%     kernel_I = [0.3535 0.4472 0.5 0.4472 0.3535; 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.5 1 0 1 0.5 
%                 0.4472 0.5 1 0.5 0.4472
%                 0.3535 0.4472 0.5 0.4472 0.3535];
% %     kernel_I = [0.125 0.25 0.125
% %                 0.25 0 0.25
% %                 0.125 0.25 0.125];
%     kernel_I = a.* kernel_I
%     kernel_E = 1; 

%*****************form a 13*13 mat*********************************
B=[]; % distributed triu,225'
for i =1:2*r+1 % ori:13, plot:51
    for j=1:2*r+1
        if i<=j
            B(i,j)=(2*r+1-j+i)/10; %(13-j+i)/10;(j-i)/10
        else
            B(i,j)=0;
        end
    end
end

% B = A; % down
B_l = rot90(B,2); % 45', up
C = rot90(B,1); % -45', right
C_l = rot90(C,2); % 135',left
%******************************************************************
%**********distributed excitation and inhibition kernels***********    
    Tempkernel = DOGAnalysis(a, sigma_I(h)/sigma_E(k) , sigma_E(k), r ,k);  %Func(a,b,sigma,r);
    kernel_E = GaussAnalysis(sigma_E(k),r);
    kernel_E(ht<1) = Tempkernel(ht<1);   %To form distributed time delay, which is determined by the h(t) distribution.(Self-inhibition involved here)
    kernel_E(ht>1) = 0;
    kernel_E(kernel_E<0) = 0;
    Showkerne_E = round (kernel_E*100);

    kernel_I = a * GaussAnalysis(sigma_I(h),r);
    kernel_I(ht<1) =0; %(here I make the h(t) distribution in this principle: delay=0 when ht<1, otherwise delay=1)
    kernel_I_delay1 = kernel_I;

    kernel_I_delay1(ht<1) =0;
    kernel_I_delay1(ht>1.8999) =0;
    Showkernel_I_delay1 = round (kernel_I_delay1*100);
    % modified kernel_I
    kernel_I_delay1_B_u = kernel_I_delay1.*B; % 225',.*Sigmoid(270, x, y)
    kernel_I_delay1_B_l = kernel_I_delay1.*B_l; % 45',.*Sigmoid(90, x, y)
    kernel_I_delay1_C_u = kernel_I_delay1.*C; % -45',.*Sigmoid(180, x, y)
    kernel_I_delay1_C_l = kernel_I_delay1.*C_l; % 135',.*Sigmoid(0, x, y)
    
    kernel_I_delay2 = kernel_I;
    kernel_I_delay2(ht<1.8999) =0;
    Showkernel_I_delay2 = round (kernel_I_delay2*100);
    kernel_I_delay2_B_u = kernel_I_delay2.*B; %.*Sigmoid(270, x, y)
    kernel_I_delay2_B_l = kernel_I_delay2.*B_l; %.*Sigmoid(90, x, y)
    kernel_I_delay2_C_u = kernel_I_delay2.*C; % .*Sigmoid(180, x, y)
    kernel_I_delay2_C_l = kernel_I_delay2.*C_l; % .*Sigmoid(0, x, y)
%*****************************************************  
%*****************************************************
tic;
t1 = toc;
    for i=FrameSTRT_Num+Max_delay:FrameEnd_Num
        FileName = strcat (FilePath,num2str(i-3),'.bmp');
        Frame1 = imread(FileName);
        Frame1 = im2single (Frame1);
        FileName = strcat (FilePath,num2str(i-2),'.bmp');
        Frame2 = imread(FileName);
        Frame2 = im2single (Frame2);
        FileName = strcat (FilePath,num2str(i-1),'.bmp');
        Frame3 = imread(FileName);
        Frame3 = im2single (Frame3);
        FileName = strcat (FilePath,num2str(i),'.bmp');
        Frame4 = imread(FileName);
        Frame4 = im2single (Frame4);
        
        Frame_Diff1 = abs(Frame2 - Frame1);
        Frame_Diff2 = abs(Frame3 - Frame2);
        Frame_Diff3 = abs(Frame4 - Frame3);
        
        FFI(i) = sum(sum(Frame_Diff1));
        Thresh_G(i) = FFI(k,i)*0.001/200 * Thresh_G_0;
        Thresh_G(i) = min(Thresh_G(i),0.3);
       
%       (Note: Layer_I = currentframe (conv) kernel_I_delay0 + delayed_1frame (conv)
%       kernel_I_delay1 +delayed_2frame (conv) kernel_I_delay2)
        Layer_E = conv2(Frame_Diff3,kernel_E,'same');
        Layer_I_delay1_B_u = conv2(Frame_Diff2,kernel_I_delay1_B_u,'same');
        Layer_I_delay1_B_l = conv2(Frame_Diff2,kernel_I_delay1_B_l,'same');
        Layer_I_delay1_C_u = conv2(Frame_Diff2,kernel_I_delay1_C_u,'same');
        Layer_I_delay1_C_l = conv2(Frame_Diff2,kernel_I_delay1_C_l,'same');
        
        Layer_I_delay2_B_u = conv2(Frame_Diff1,kernel_I_delay2_B_u,'same');
        Layer_I_delay2_B_l = conv2(Frame_Diff1,kernel_I_delay2_B_l,'same');
        Layer_I_delay2_C_u = conv2(Frame_Diff1,kernel_I_delay2_C_u,'same');
        Layer_I_delay2_C_l = conv2(Frame_Diff1,kernel_I_delay2_C_l,'same');
        
        Layer_I_B_u = Layer_I_delay1_B_u + Layer_I_delay2_B_u;  %delay0 has been involved to kernal E.
        Layer_I_B_l = Layer_I_delay1_B_l + Layer_I_delay2_B_l;
        Layer_I_C_u = Layer_I_delay1_C_u + Layer_I_delay2_C_u;  
        Layer_I_C_l = Layer_I_delay1_C_l + Layer_I_delay2_C_l;
        
        Layer_S_B_u = Layer_E - Layer_I_B_u;
        Layer_S_B_l = Layer_E - Layer_I_B_l;
        Layer_S_C_u = Layer_E - Layer_I_C_u;
        Layer_S_C_l = Layer_E - Layer_I_C_l;
       
%        imwrite(Layer_S_B_u,strcat('F:\code\gu_-drone\D-LGMD (Matlab)\results\Layer_S_B_u_chair\',num2str(i),'.bmp'));
%*****************************sliding window*******************************
       [wid,ht] = size(Layer_S_B_u); % chair,540*960
       % the results are related to the size of bbox 
%        240 320 80 80
       win_w =80; % round(w/5);181,300,400
       win_h = 80; % round(h/5);181,300,400
       win_step = 50; % 50;100
       %960 540  忘记了
%        win_w = 300; % round(w/5);181,300,400
%        win_h = 300; % round(h/5);181,300,400
%        win_step = 100; % 50;100

       i_all = [];
       j_all = [];
       for m = 1:win_step:(wid-win_w)
           for n = 1:win_step:(ht-win_h)    
               temp_img_B_u = Layer_S_B_u(m:m+win_w-1, n:n+win_h-1, :); % acquire bbox 
               temp_img_B_l = Layer_S_B_l(m:m+win_w-1, n:n+win_h-1, :);
               temp_img_C_u = Layer_S_C_u(m:m+win_w-1, n:n+win_h-1, :); 
               temp_img_C_l = Layer_S_C_l(m:m+win_w-1, n:n+win_h-1, :);
               
               temp_img_B_u(temp_img_B_u<0) =0;      
               temp_img_B_l(temp_img_B_l<0) =0;
               temp_img_C_u(temp_img_C_u<0) =0;      
               temp_img_C_l(temp_img_C_l<0) =0;
               
               temp_Layer_S_B_u_r = rot90(temp_img_B_u,2);
               temp_S1 = temp_Layer_S_B_u_r.*temp_img_B_l; % downleft
               temp_Layer_S_B_l_r = rot90(temp_img_B_l,2);
               temp_S2 = temp_Layer_S_B_l_r.*temp_img_B_u; % upright
               temp_S12 = temp_S1 + temp_S2; % the symmetric area,1/3 quadrant 
               temp_Layer_S_C_u_r = rot90(temp_img_C_u,2);
               temp_S3 = temp_Layer_S_C_u_r.*temp_img_C_l; % downright
               temp_Layer_S_C_l_r = rot90(temp_img_C_l,2);
               temp_S4 = temp_Layer_S_C_l_r.*temp_img_C_u; % upleft
               temp_S34 = temp_S3 + temp_S4; % the symmetric area,2/4 quadrant
               temp_S12_r = rot90(temp_S12,1);
               temp_S = temp_S1 + temp_S2 + temp_S3 + temp_S4; % 2 opposite angles
%                temp_S = temp_S12_r.*temp_S34;
               
               % select the bbox
               temp_sum_S = sum(sum(temp_S));
               if temp_sum_S>1 % the threshold; 0.05,0.01
                  % select the symmetric pixels
                   data = temp_S;
%                    [row,column] = find(data==max(max(data))); % location of the max pixel
%                    data_max = max(max(data))
                   temp_data_max = max(max(temp_S));
                   [row,column] = find(data>=temp_data_max*0.3 & data<=temp_data_max);
                   temp_i = row+m;
                   i_all = vertcat(i_all,temp_i);  
                   temp_j = column+n;
                   j_all = vertcat(j_all,temp_j); % locations of each frame
               end        
%                imwrite(tmp_img_u,strcat('F:\code\gu_-drone\D-LGMD (Matlab)\dataset\slidewindow_tmpimg_u\',num2str(i),'_',num2str(m),'_',num2str(n),'.bmp'));            
%                figure(1);
%                imshow(temp_S);
%                title(strcat(num2str(i),'\_',num2str(m),'\_',num2str(n)));
           end
       end 
       temp_sum_S_max(i) = max(max(temp_sum_S)); % plot
%**************************************************************************         
%***********************original Layer_S***********************************
       Layer_I_delay1 = conv2(Frame_Diff2,kernel_I_delay1,'same');
       Layer_I_delay2 = conv2(Frame_Diff1,kernel_I_delay2,'same');
       Layer_I = Layer_I_delay1 + Layer_I_delay2;  %delay0 has been involved to kernal E.
       Layer_S = Layer_E - Layer_I;
       Layer_S(Layer_S<0) =0;
%*********************enhance Layer_S**************************************
       Layer_S_enhancement = Layer_S;    
       for i_idx = 1:length(i_all)
%            Layer_S_enhancement(i_all(i_idx),j_all(i_idx)) = Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*100;
%            Layer_S_enhancement(i_all(i_idx),j_all(i_idx)) = Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*Layer_S(i_all(i_idx),j_all(i_idx)).*50;
           Layer_S_enhancement(i_all(i_idx),j_all(i_idx)) = Layer_S_enhancement(i_all(i_idx),j_all(i_idx)).*Layer_S(i_all(i_idx),j_all(i_idx));

       end
%         figure(6)         
%         imshow(Layer_S_enhancement);   
%         title([num2str(i),'th Frame']);
%**********************************************
% %*************FFM-GD*************************
       Layer_G_Cef = conv2(Layer_S,kernalG,'same');
       Layer_G = Layer_S .* Layer_G_Cef;
       Layer_G(Layer_G<Thresh_G(i))=0; %Thresh_G(i)
       Layer_G(Layer_G>1)=1;
        
       LGMD_OutputS(k,i) = sum(sum(Layer_S));    %**output of G or S layer
       LGMD_OutputG(k,i) = sum(sum(Layer_G));    %**output of G or S layer
       LGMD_Outputsum_S(k,i) = sum(sum(Layer_S_enhancement)); 
    
    end
    Normalized_OutS(k,1:i) = mapminmax(LGMD_OutputS(k,:), 0, 1);
%     Normalized_OutG(k,1:i) = mapminmax(LGMD_OutputG(k,:), 0, 1);
    Oppnency_output(k,1:i) = mapminmax(LGMD_Outputsum_S(k,:), 0, 1);
    end
end
t2 = toc;
RunTime2(rrr) = t2-t1
%---------------------------------------------------------Oppnency---------------------------------------------------------------------------------
%---------------------------------------------------------Optical_divergence---------------------------------------------------------------------------------
load opticalFlowTest;

tic;
t1 = toc;
for k=FrameSTRT_Num+1:FrameEnd_Num
    FileName = strcat (FilePath,num2str(k-1),'.bmp');
    I1 = imread(FileName);
    FileName = strcat (FilePath,num2str(k),'.bmp');
    I2 = imread(FileName);


    %basketball 【】，suv【】，uav【】

    I1=imresize(im2single(I1),[240,320]);I2=imresize(im2single(I2),[240,320]);
%     I1=imresize(im2single(I1),[240,320]);I2=imresize(im2single(I2),[240,320]);
%     I1=imresize(im2single(I1),[240,320]);I2=imresize(im2single(I2),[240,320]);
    [n,m]=size(I2);
    m=320;
    n=240;
    [Vx,Vy]=opticalFlow(I1,I2,'smooth',1,'radius',10,'type','LK');
    A=0;
    Ax=0;
    Ay=0;
    D=0;
    Dx=0;
    Dy=0;

    for i=(m/10):(3*m/10)
        for j=(9*n/20):(12*n/20)
%             A=sqrt(Vx(j,i)*Vx(j,i)+Vy(j,i)*Vy(j,i))+A;
            Ax=Ax+Vx(j,i);
            Ay=Ay+Vy(j,i);
        end
    end

    for i=(7*m/10):1:(9*m/10)
        for j=(9*n/20):1:(12*n/20)
%             D=sqrt(Vx(j,i)*Vx(j,i)+Vy(j,i)*Vy(j,i))+D;
            Dx=Dx+Vx(j,i);
            Dy=Dy+Vy(j,i);
        end
    end
    S(k)=sqrt((Dx-Ax)^2+(Dy-Ay)^2);
%     S(k)=(abs(D+A));
    


% subplot(1,2,1),imshow(double(Vx),[]);
% subplot(1,2,2),imshow(double(Vy),[]);

% imshow(I2)
% hold on
% [X,Y] = meshgrid(1:size(Vx,2),1:size(Vx,1));
% % [X,Y] = meshgrid();
% U = abs(Vy);
% V = abs(Vx);
% quiver(X,Y,U,V,0);
% hold off    
end
t2 = toc;
RunTime3(rrr) = t2-t1
% S(37)=S(36);
% S(37)=max(S);
Optical_divergence_output = mapminmax(S,0, 1);
% Optical_divergence_output(1)=0;
% sssss = log10(S);
% Optical_divergence_output = mapminmax(sssss,0, 1);
%---------------------------------------------------------Optical_divergence---------------------------------------------------------------------------------
%---------------------------------------------------------A_LGMD     chair 使用原始大小，r1=2，r2=4.。。其他数据集统一【240320】，r1=1，r2=2---------------------------------------------------------------------------------
%------------------------------kernel-----------------------------------
r1=1;  
kernel_I2=1*kernel(r1,r1,0);%参数（sigma，卷积核半径，卷积核类型0 or 1）%0是选低速，1是选高速
r2=1;
kernel_I3=kernel(r2,r2,1);
r_A=2*r2-r1+1;
kernel_A=ones(2*r_A+1);
%---------izhikevich parament---------
k=1;%计量神经元模型的个数
a=0.02;
b=0.2;
c=-65;
d=2;
v=zeros(1,FrameEnd_Num);
u=zeros(1,FrameEnd_Num);
v(1)=-65;
u(1)=0;
%----------遍历文件夹图片，当指定开始和结束帧时注释下面代码
% fileExt = '*.bmp';  %待读取图像的后缀名
% %获取所有路径
% files = dir(fullfile(FilePath,fileExt)); 
% FrameEnd_Num = size(files,1);
% FrameEnd_Num =134;
%-------------神经脉冲尖峰信息存储
A_num=zeros(1,FrameEnd_Num);
V3_num=zeros(1,FrameEnd_Num);
Soma=zeros(1,FrameEnd_Num);

q=zeros(1,FrameEnd_Num);%frams
w=zeros(1,FrameEnd_Num);%spike intensity
spike=0;
%*********************************setup***************
[img_past,img_now,img_diff1,img_diff2,img_diff3]=deal(zeros());
ii=0;%读取多少张
i=0;%除去相同的图片，有效的差分图张数
flag=1;%
tic;
t1 = toc;
% i=120;
while flag==1 && ii<FrameEnd_Num
    ii=ii+1;
    FileName = strcat (FilePath,num2str(ii),'.bmp'); 
    temp=imread(FileName);
    %240*320将图片归一化刀240320的分辨率
    img_now=imresize(im2single(temp),[240,320]);%会导致取点不连续
%     img_now=imresize(im2single(temp),1);
    img_diff3=abs(img_now-img_past);
    sum(sum(img_diff3));
    if sum(sum(img_diff3))==0   
        continue
    else
        i=i+1;
    end
%     i=i+1;
    if  i>2 
        Layer_V2=(img_diff2-conv2(img_diff1,kernel_I2,'same')); 
        Layer_V23=(img_diff2-conv2(img_diff1,kernel_I3,'same')); 
        Layer_V3=(img_diff3-conv2(img_diff2,kernel_I3,'same'));

        %求加速度信息
        Layer_V3(Layer_V3<0.1)=0;
        Layer_temp = conv2(Layer_V3,kernel_A,'same');
        Layer_A=Layer_temp.*imbinarize(Layer_V2,0.03).*abs((imbinarize(Layer_V23,0.1)-1));
%         写入
%         imwrite(img_diff2,strcat("C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\output\P\",num2str(i-1),".bmp"));
%         imwrite(Layer_V2,strcat("C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\output\V2\",num2str(i-1),".bmp"));
%         imwrite(Layer_V23,strcat("C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\output\V3\",num2str(i-1),".bmp"));
%         imwrite(Layer_A,strcat("C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\output\A\",num2str(i-2),".bmp"));
% %         %计算具有速度，加速度的像素点个数
        A_num(i)=sum(sum(Layer_A>0.1));
        V3_num(i)=sum(sum(Layer_V3>0));
        Soma(i)=A_num(i)*V3_num(i);
        %old PDS
%         Output_temp(i)=max(0,A_num(i)-V3_num(i));    
%         Output(i)=Output_temp(i).*V3_num(i);
%-------------------------izhikevich----------------
        k=k+1;
        [v(k),u(k)]=Izhikevich_model(v(k-1),u(k-1),Soma(i),10^-3*k/30,a,b);%v,u,I,t,a,b
        if v(k)>=30
            v(k)=c;
            u(k)=u(k-1)+d;
        end
%         终止条件和记录脉冲        
        if k>3 && v(k-1)>v(k) && v(k-1)>v(k-2) && v(k-1)>-25
            spike=spike+1;
            q(spike)=i-2;
            w(spike)=v(q(spike));
        end
        %画出中间过程
%         figure(1)
%         subplot(221)
%         imshow(img_diff3); 
%         title(strcat('P_',num2str(i)));
% %         figure(2)
%         subplot(222)
%         Layer_V2(Layer_V2<0.1)=0;
%         imshow(Layer_V2);   
%         title(strcat('V2_',num2str(i)));
% %         figure(3)
%         subplot(223)
%         imshow(Layer_V3);   
%         title(strcat('V3_',num2str(i)));
%         figure(4)
% %         subplot(224)
%         imshow(imresize(Layer_A,1));
%         title(strcat('A_',num2str(i)));
        %画出PVA的点数和
%         figure(2326)   
%         hold on
%         s1(i)=sum(sum(img_diff3));
%         s2(i)=sum(sum(Layer_V2>0));
%         s3(i)=sum(sum(Layer_V3>0));
%         s4(i)=sum(sum(Layer_A>0));
%         plot(1:i,s1)
%         plot(1:i,s2)
%         plot(1:i,s3,'LineStyle',':')
%         plot(1:i,s4,'LineStyle','--')
        
%         figure(789)
% %         normal_s2=mapminmax(s2,0,5);
%         plot(p,s2)
%         figure(7899)
% %         normal_s3=mapminmax(s3,0,5);
%     %         normal_s4=mapminmax(s4,0,5);
%         plot(p,s3)
%         figure(78999)
% %         normal_s2=mapminmax(s2,0,5);
%         plot(p,s4)

        %画出soma和神经元输出
%         figure(2)
%         hold on
%         yyaxis left
%         plot (1:i,A_num(1:i),'linewidth',2,'linestyle','-');
% %         plot (1:i,Soma(1:i),'linewidth',2,'linestyle','-');
%         ylabel('Soma');
% 
%         yyaxis right
%         plot (1:k,v(1:k),'linewidth',2,'linestyle','-');
%         ylabel('izhikevich');
%         title(strcat('neuron_',num2str(i)));
    end
    img_past=img_now;
    img_diff1=img_diff2;
    img_diff2=img_diff3;
end
t2 = toc;
RunTime4(rrr) = t2-t1
A_LGMD_output = mapminmax(v,0, 1);

% -------------experiment 1-----------
% figure(2326)   
% hold on
% title("ALGMD's capacities of extract veolcity and acceleration")
% yyaxis left
% % plot(1:i,s1,"r")
% plot(p,s2,'linewidth',2)
% plot(p,s3,'linewidth',2)
% plot(p,s4,'linewidth',2)
% ylabel("Numbers of V or A")
% 
% yyaxis right
% looming_veolcity=[0	0.0518326545723808	0.0532724505327247	0.0547730829420967	0.0563380281690140	0.0579710144927539	0.0596760443307760	0.0614574187884100	0.0633197648123023	0.0652680652680662	0.0673076923076916	0.0694444444444446	0.0716845878136203	0.0740349021681652	0.0765027322404368	0.0790960451977396	0.0818234950321450	0.0846944948578345	0.0877192982456139	0.0909090909090908	0.0942760942760943	0.0978336827393438	0.101596516690856	0.105580693815988	0.109803921568628	0.114285714285714	0.119047619047619	0.124113475177305	0.129509713228493	0.135265700483092	0.141414141414142	0.147991543340380	0.155038759689923	0.162601626016260	0.170731707317073	0.179487179487179	0.188933873144401	0.199146514935988	0.210210210210211	0.222222222222221	0.235294117647060	0.249554367201425	0.265151515151516	0.282258064516128	0.301075268817206	0.321839080459771	0.344827586206895	0.370370370370372	0.398860398860398	0.430769230769233	0.466666666666665	0.507246376811596	0.553359683794465	0.606060606060607	0.666666666666664	0.736842105263161	0.818713450292394	0.915032679738566	1.02941176470588	1.16666666666667	1.33333333333333	1.53846153846155	1.79487179487179	2.12121212121212	2.54545454545454	3.11111111111114	3.88888888888888	4.99999999999999	5	5	5	5	5];
% plot(looming_veolcity,'linewidth',2)
% legend('V1','V2','A','looming veolcity','location','best')
% ylabel("Veolcity of looming")
% xlabel('Frams');
% 
% 
% %绘制局部细节图
% ax = axes('Position',[0.5 0.65 0.25 0.25]);
% box on;
% hold on;
% pp=19:25;
% plot(pp+45,s2(pp),'linewidth',2)
% plot(pp+45,s3(pp),'linewidth',2)
% plot(pp+45,s4(pp),'linewidth',2)
% legend('V1','V2','A','location','best')
% 
% xlabel('Frams');
% ylabel("Numbers of V or A");
% 
% title('局部放大图- 细节显示');


% figure(232323)
% hold on
% yyaxis left
% ylabel("Number of dangerous pixel")  
% % plot(V2_num,'linewidth',2)
% % plot(V3_num,'linewidth',2)
% plot(A_num,'linewidth',2)
% % plot(V3_num)
% 
% yyaxis right
% ylabel("ALGMD's neural spike")  
% plot(v,'linewidth',2)
% plot(q(1),w(1),'rs') 
% % text(q(1),w(1),['Trigger'])
% % text(q(1)-40,w(1),['Trigger(' num2str(q(1)) ',' num2str(w(1)) ')'])
% legend('Number of Layer A ','Neural spike','Trigger','location','NorthWest')
end
% mean(RunTime0)
mean(RunTime1)
mean(RunTime2)
mean(RunTime3)
mean(RunTime4)
q(1)
%---------------------------------------------------------A_LGMD---------------------------------------------------------------------------------
% *****************plots********************************************************************************
% RunTime1,RunTime2,RunTime3,RunTime4
find(D_LGMD_output>0.3)
find(Oppnency_output>0.3)
find(Optical_divergence_output>0.3)
% find(A_LGMD_output>0.3)
    figure (10)
    hold on
%     yyaxis left
%     plot (1:FrameEnd_Num,Optical_DVS_output(1:FrameEnd_Num),'linewidth',2,'linestyle','-')
    plot (1:FrameEnd_Num,D_LGMD_output(1,(1:FrameEnd_Num)),'linewidth',2,'linestyle','-');
    plot (1:FrameEnd_Num,Oppnency_output(1,(1:FrameEnd_Num)),'linewidth',2,'linestyle','-');
    
    plot (1:FrameEnd_Num,Optical_divergence_output(1:FrameEnd_Num),'linewidth',2,'linestyle','-')
    plot (1:FrameEnd_Num,A_LGMD_output(1,(1:FrameEnd_Num)),'linewidth',2,'linestyle','-');
    xlabel('Frames');
    ylabel('Normalised Output');
    
%     yyaxis right
%     ylabel("ALGMD's neural spike")  
%     plot(v,'linewidth',2)
    plot(q(1),A_LGMD_output(q(1)),'rs') 

%     legend('Optical-DVS','D-LGMD','OppLoD','Optical-divergence','A-LGMD','location','NorthWest')
    legend('D-LGMD','OppLoD','Optical-divergence','A-LGMD','location','NorthWest')


