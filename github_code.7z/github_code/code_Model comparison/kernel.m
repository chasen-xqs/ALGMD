function val = kernel(sigma,r,p)%p=0 低速滤波核，p=1 高速滤波核
%-------------------version1-----------
% o=(d+1)/2;
% Z=zeros(d,d);
% for a=1: d
%     for b=1: d
%         if (a-o)^2+(b-o)^2<=r^2
%             Z(a,b)=2;
%         end
%     end
% end
% %-------------------version2-----------
x=-r:1:r;
y=-r:1:r;
[X,Y]=meshgrid(x,y);

amplitude = 1 / (2*pi*sigma^2); 
exponent1 = ((X).^2 + (Y).^2)./(2*sigma.^2);
if p==0
    Z=amplitude  * (1-exp(-exponent1));%选低速
else
    Z=amplitude  * exp(-exponent1);
end
Z(Z==0)=10;
min(min(Z));
k=round(1/min(min(Z)));
Z(Z==10)=0;
% k=1;

for a=1: 2*r+1
    for b=1: 2*r+1
        if ((a-r-1)^2+(b-r-1)^2)>r^2
            Z(a,b)=0;
        else
            Z(a,b)=Z(a,b)*k;
        end
    end
end
Z(r+1,r+1)=1;
% Z(o,o)=0.01;
% x=-r/2:1:r/2;
% y=-r/2:1:r/2;
% [X,Y]=meshgrid(x,y);

%     for a=1: d
%         for b=1: d
%             if (a-o)^2+(b-o)^2<=r3^2
%                 Z(a,b)=1;
%             end
%             if (a-o)^2+(b-o)^2<=r2^2
%                 Z(a,b)=2;
%             end
%              if (a-o)^2+(b-o)^2<=r1^2
%                 Z(a,b)=3;
%             end
%         end
%     end  

% figure,mesh(X,Y,Z);
val       =Z;