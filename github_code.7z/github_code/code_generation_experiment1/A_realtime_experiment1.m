clear;clc;
%**************Claimed Parameters********************************
FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\real world\d=5 v=2 looming\';FrameEnd_Num =72;
%--------------------240320--------------
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\box\';FrameEnd_Num =33;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\ball\';FrameEnd_Num =37;
% % % 
% % % FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\chair\';FrameEnd_Num =120;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\chair\';FrameEnd_Num =120;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\QRcode_0.5\';FrameEnd_Num =134;
% % % 
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV3_movingcar\';FrameEnd_Num =32;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV2_basketballstick\';FrameEnd_Num =54;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\240320group1-7\FPV4_uav\';FrameEnd_Num =42;
%--------------------------------------
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\l05v1\';FrameEnd_Num =79;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\l1v1\';FrameEnd_Num =68;kkk=100;

% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\l1v1\';FrameEnd_Num =68;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\l05v1\';FrameEnd_Num =79;

% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\box\';FrameEnd_Num =33;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\ball\';FrameEnd_Num =37;

% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\chair\';FrameEnd_Num =120;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\QRcode_0.5\';FrameEnd_Num =134;

% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\FPV3_movingcar\';FrameEnd_Num =32;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\FPV2_basketballstick\';FrameEnd_Num =54;
% FilePath = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\data\FPV4_uav\';FrameEnd_Num =42;

%---------------savefilepath----------------------------------
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\QRcode_0.5\';FrameEnd_Num =134;
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\l1v1\';
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\l05v1\';
% % 
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\box\';FrameEnd_Num =33;
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\ball\';FrameEnd_Num =37;
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\chair\';FrameEnd_Num =120;
% 
% FilePath_save ='C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\FPV3_movingcar\';FrameEnd_Num =32;
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\FPV2_basketballstick\';FrameEnd_Num =54;
% FilePath_save = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\FPV4_uav\';FrameEnd_Num =42;
%---------------savefilepath——hot----------------------------------
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\QRcode_0.5\';FrameEnd_Num =134;
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\l1v1\';
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320_hot\l05v1\';
% 
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\box\';FrameEnd_Num =33;
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\ball\';FrameEnd_Num =37;
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\chair\';FrameEnd_Num =120;
% 
% FilePath_save_hot ='C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\FPV3_movingcar\';FrameEnd_Num =32;
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\FPV2_basketballstick\';FrameEnd_Num =54;
% FilePath_save_hot = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\matlab output\ALGMD240320\FPV4_uav\';FrameEnd_Num =42;
%---------------savefilepath——hot----------------------------------

%------------------------------kernel-----------------------------------
r1=2;  
kernel_I2=1*kernel(r1,r1,0);%参数（sigma，卷积核半径，卷积核类型0 or 1）%0是选低速，1是选高速
r2=4;
kernel_I3=kernel(r2,r2,1);
r_A=2*r2-r1+1;
kernel_A=ones(2*r_A+1);
%---------izhikevich parament---------
k=1;%计量神经元模型的个数
a=0.02;
b=0.2;
c=-65;
d=2;
v=zeros(1,FrameEnd_Num);
u=zeros(1,FrameEnd_Num);
v(1)=-65;
u(1)=0;
%----------遍历文件夹图片，当指定开始和结束帧时注释下面代码
% fileExt = '*.bmp';  %待读取图像的后缀名
% %获取所有路径
% files = dir(fullfile(FilePath,fileExt)); 
% FrameEnd_Num = size(files,1);
% FrameEnd_Num =134;
%-------------神经脉冲尖峰信息存储
A_num=zeros(1,FrameEnd_Num);
V3_num=zeros(1,FrameEnd_Num);
Soma=zeros(1,FrameEnd_Num);

q=zeros(1,FrameEnd_Num);%frams
w=zeros(1,FrameEnd_Num);%spike intensity
spike=0;
%*********************************setup***************
[img_past,img_now,img_diff1,img_diff2,img_diff3]=deal(zeros());
ii=0;%读取多少张
i=0;%除去相同的图片，有效的差分图张数
flag=1;%
tic;
t1 = toc;
% i=120;
while flag==1 && ii<FrameEnd_Num
    ii=ii+1;
    FileName = strcat (FilePath,num2str(ii),'.bmp'); 
    temp=imread(FileName);
    %240*320将图片归一化刀240320的分辨率
    img_now=imresize(im2single(temp),[240,320]);%会导致取点不连续
%     img_now=imresize(im2single(temp),1);
    img_diff3=abs(img_now-img_past);
    sum(sum(img_diff3));
%     if sum(sum(img_diff3))==0   
%         continue
%     else
%         i=i+1;
%         ii;
%     end
    i=i+1;
    if  i>2 
        Layer_V2=(img_diff2-conv2(img_diff1,kernel_I2,'same')); 
        Layer_V23=(img_diff2-conv2(img_diff1,kernel_I3,'same')); 
        Layer_V3=(img_diff3-conv2(img_diff2,kernel_I3,'same'));

        %求加速度信息
        Layer_V3(Layer_V3<0.1)=0;
        Layer_temp = conv2(Layer_V3,kernel_A,'same');
        Layer_A=Layer_temp.*imbinarize(Layer_V2,0.03).*abs((imbinarize(Layer_V23,0.1)-1));
%         写入
%         imwrite(img_diff2,strcat("C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\output\P\",num2str(i-1),".bmp"));
%         imwrite(Layer_V2,strcat("C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\output\V2\",num2str(i-1),".bmp"));
%         imwrite(Layer_V23,strcat("C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\output\V3\",num2str(i-1),".bmp"));
%         imwrite(Layer_A,strcat(FilePath_save,num2str(i),".bmp"));
% %         %计算具有速度，加速度的像素点个数
        A_num(i)=sum(sum(Layer_A>0.1));
        V3_num(i)=sum(sum(Layer_V3>0));
        Soma(i)=A_num(i)*V3_num(i);


        
        %old PDS
%         Output_temp(i)=max(0,A_num(i)-V3_num(i));    
%         Output(i)=Output_temp(i).*V3_num(i);
%-------------------------izhikevich----------------
        k=k+1;
        [v(k),u(k)]=Izhikevich_model(v(k-1),u(k-1),Soma(i),10^-3*k/30,a,b);%v,u,I,t,a,b
        if v(k)>=30
            v(k)=c;
            u(k)=u(k-1)+d;
        end
%         终止条件和记录脉冲        
        if k>3 && v(k-1)>v(k) && v(k-1)>v(k-2) && v(k-1)>-25
            spike=spike+1;
            q(spike)=i-2;
            w(spike)=v(q(spike));
        end
        %画出中间过程
%         figure(1)
%         subplot(221)
%         imshow(img_diff3); 
%         title(strcat('P_',num2str(i)));
% %         figure(2)
%         subplot(222)
%         Layer_V2(Layer_V2<0.1)=0;
%         imshow(Layer_V2);   
%         title(strcat('V2_',num2str(i)));
% %         figure(3)
%         subplot(223)
%         imshow(Layer_V3);   
%         title(strcat('V3_',num2str(i)));
        figure(4)
%         subplot(224)
        imshow(imresize(Layer_A,1));
        title(strcat('A-',num2str(i)));
        %画出PVA的点数和
%         figure(2326)   
%         hold on
        s1(i)=sum(sum(img_diff3));
        s2(i)=sum(sum(Layer_V2>0));
        s3(i)=sum(sum(Layer_V3>0));
        s4(i)=sum(sum(Layer_A>0));
        xxx=mapminmax(s4,0,1);
        xxy=mapminmax(v,0,1);
        
%         plot(1:i,s1)
%         plot(1:i,s2)
%         plot(1:i,s3,'LineStyle',':')
%         plot(1:i,s4,'LineStyle','--')
        
%         figure(789)
% %         normal_s2=mapminmax(s2,0,5);
%         plot(p,s2)
%         figure(7899)
% %         normal_s3=mapminmax(s3,0,5);
%     %         normal_s4=mapminmax(s4,0,5);
%         plot(p,s3)
%         figure(78999)
% %         normal_s2=mapminmax(s2,0,5);
%         plot(p,s4)

        %画出soma和神经元输出
%         figure(2)
%         hold on
%         yyaxis left
%         plot (1:i,A_num(1:i),'linewidth',2,'linestyle','-');
% %         plot (1:i,Soma(1:i),'linewidth',2,'linestyle','-');
%         ylabel('Soma');
% 
%         yyaxis right
%         plot (1:k,v(1:k),'linewidth',2,'linestyle','-');
%         ylabel('izhikevich');
%         title(strcat('neuron_',num2str(i)));
    end
% %------------------------DLGMD------------------
%         FFI(i) = sum(sum(img_diff1));
%        Thresh_G(i) = FFI(i)*0.001/200 * Thresh_G_0;
%        Thresh_G(i) = min(Thresh_G(i),0.3);
%        
% %       (Note: Layer_I = currentframe (conv) kernel_I_delay0 + delayed_1frame (conv)
% %       kernel_I_delay1 +delayed_2frame (conv) kernel_I_delay2)
%         Layer_E = conv2(img_diff3,kernel_E1,'same');
%         Layer_I_delay1 = conv2(img_diff2,kernel_I_delay1,'same');
%         Layer_I_delay2 = conv2(img_diff1,kernel_I_delay2,'same');
%         Layer_I = Layer_I_delay1 + Layer_I_delay2;  %delay0 has been involved to kernal E.
%         
%        Layer_S = Layer_E - Layer_I;
%        Layer_S(Layer_S<0) =0;      %results will not be negative.
%        
%        sum_p=sum(sum(Frame_Diff3));
%         sum_s=sum(sum(Layer_S));
% %         PS=sum_s/sum_p;
% % %*************FFM-GD***************
%        Layer_G_Cef = conv2(Layer_S,kernalG,'same');
%        Layer_G =Layer_S .* Layer_G_Cef;
% %        Layer_G=Layer_S;
% 
%         Layer_G(Layer_G<Thresh_G(i))=0;%change yuzhi
%         Layer_G(Layer_G>1)=1;
% %------------------------DLGMD------------------
%     figure(1)
%         subplot(131)
%         imshow(img_now);  
%         title(strcat('P',num2str(i)));
%         subplot(132)
%         imshow(Layer_G);  
%         title(strcat('DLGMD',num2str(i)));
%         subplot(133)
%         imshow(Layer_A); 
%         title(strcat('ALGMD',num2str(i)));
    img_past=img_now;
    img_diff1=img_diff2;
    img_diff2=img_diff3;
end
t2 = toc;
RunTime = t2-t1


% -------------experiment 1-----------
figure(2326)   
hold on
title("ALGMD's capacities of extract veolcity and acceleration")
yyaxis left
% plot(1:i,s1,"r")
plot(1:i,s2,'linewidth',2,'LineStyle',':')
plot(1:i,s3,'linewidth',2,'LineStyle','--')
plot(1:i,s4,'linewidth',2,'LineStyle','-')
ylabel("Numbers of V or A")

yyaxis right
looming_veolcity=[0	0.0518326545723808	0.0532724505327247	0.0547730829420967	0.0563380281690140	0.0579710144927539	0.0596760443307760	0.0614574187884100	0.0633197648123023	0.0652680652680662	0.0673076923076916	0.0694444444444446	0.0716845878136203	0.0740349021681652	0.0765027322404368	0.0790960451977396	0.0818234950321450	0.0846944948578345	0.0877192982456139	0.0909090909090908	0.0942760942760943	0.0978336827393438	0.101596516690856	0.105580693815988	0.109803921568628	0.114285714285714	0.119047619047619	0.124113475177305	0.129509713228493	0.135265700483092	0.141414141414142	0.147991543340380	0.155038759689923	0.162601626016260	0.170731707317073	0.179487179487179	0.188933873144401	0.199146514935988	0.210210210210211	0.222222222222221	0.235294117647060	0.249554367201425	0.265151515151516	0.282258064516128	0.301075268817206	0.321839080459771	0.344827586206895	0.370370370370372	0.398860398860398	0.430769230769233	0.466666666666665	0.507246376811596	0.553359683794465	0.606060606060607	0.666666666666664	0.736842105263161	0.818713450292394	0.915032679738566	1.02941176470588	1.16666666666667	1.33333333333333	1.53846153846155	1.79487179487179	2.12121212121212	2.54545454545454	3.11111111111114	3.88888888888888	4.99999999999999	5	5	5	5	5];
plot(looming_veolcity,'linewidth',2)
legend('V1','V2','A','looming veolcity','location','northwest','AutoUpdate','off')
plot(64,looming_veolcity(64),'rs','Color',[0.00,0.45,0.74]) 
plot(67,looming_veolcity(67),'rs','Color',[0.00,0.45,0.74]) 
ylabel("Veolcity of looming")
xlabel('Frams');


%绘制局部细节图
ax = axes('Position',[0.5 0.65 0.25 0.25]);
axis([64 72 0 1200]);
box on;
hold on;

pp = 64:72;
plot(pp,s2(pp),'linewidth',2,'Color',[0.00,0.45,0.74],'LineStyle',':','DisplayName','V1');
plot(pp,s3(pp),'linewidth',2,'Color',[0.00,0.45,0.74],'LineStyle','--','DisplayName','V2');
plot(pp,s4(pp),'linewidth',2,'Color',[0.00,0.45,0.74],'LineStyle','-','DisplayName','A');

h = legend('show','Location','best');
set(h,'AutoUpdate','off'); % 关闭自动更新图例

plot(64,s2(64),'rs');
plot(67,s3(67),'rs');
plot(67,s4(67),'rs');

xlabel('Frams');
ylabel("Numbers of V or A");

% title('局部放大图- 细节显示');

% figure(110)
% hold on
% plot(1:FrameEnd_Num,xxx)
% % plot(1:FrameEnd_Num,xxy)
% 0.03*(FrameEnd_Num-find(xxx>0.3));
% 
% figure(232323)
% hold on
% yyaxis left
% ylabel("Number of dangerous pixel")  
% % plot(V2_num,'linewidth',2)
% % plot(Soma,'linewidth',2)
% % plot(A_num,'linewidth',2)
% % plot(V3_num)
% 
% yyaxis right
% ylabel("ALGMD's neural spike")  
% plot(v,'linewidth',2)
% % plot(v,'linewidth',2)
% plot(q(1),w(1),'rs') 
% % text(q(1),w(1),['Trigger'])
% % text(q(1)-40,w(1),['Trigger(' num2str(q(1)) ',' num2str(w(1)) ')'])
% legend('Number of Layer A ','Neural spike','Trigger','location','NorthWest')
% q(1)


% Method izhikevich
% % 创建一些示例数据
% x = 0:0.1:10;
% y1 = sin(x);
% y2 = cos(x);
% 
% % 创建图形
% figure;
% set(gcf, 'Color', [0.99 0.80 0.67]); % 设置图形窗口的背景颜色
% 
% % 设置上半部分的坐标轴
% ax1 = axes('Position', [0.1, 0.5, 0.8, 0.39]); % 上半部分[left, bottom, width, height]
% plot(ax1, xxy, 'linewidth', 2, 'Color', [0.9 0.1 0.1])
% legend(ax1, 'Axon', 'location', 'NorthWest', 'FontSize', 40)
% axis off;
% % 设置下半部分的坐标轴
% ax2 = axes('Position', [0.1, 0.1, 0.8, 0.39]); % 下半部分
% plot(ax2, 1:FrameEnd_Num, xxx, 'linewidth', 2, 'Color', [0.2 0.5 0.72])
% legend(ax2, 'Soma', 'location', 'NorthWest', 'FontSize', 40)
% 
% % 添加共同的 X 轴标签
% xlabel('Frames');
% 
% % 关闭所有坐标轴
% axis off;


%-------------------------hot picture
% load 'Color_1'
% Colourmap = Heatmap;
% hold on
% % % % % Colourmap = colormap(jet (128));%参数取128
% FrameSTRT_Num=3;
% for k = FrameSTRT_Num:FrameEnd_Num
%     Gray = imread(strcat(FilePath_save,num2str(k),'.bmp'));
% %     Gray = rgb2gray(I);
%     ColorImage = ind2rgb(Gray, Colourmap);
%     
%     figure(1);
%     
%     
%     imshow(ColorImage);
%     ax = gca;   %显示真实的colorbar
%     colormap(ax,Heatmap)
%     colorbar;
%     imwrite(ColorImage,strcat(FilePath_save_hot,num2str(k),'.bmp'));
% end

