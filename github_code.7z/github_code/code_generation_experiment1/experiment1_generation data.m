% FilePath_looming = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\real world\d=5 v=';
% FilePath_translate = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\real world\d=5 v=';
%---------looming-------------------
% v=1;
% % 摄像头参数
% clear clc
% f=0.0028;HFOV=77.8;VFOV=55.6;xx=0.0048;yy=0.0036;
% l_loomingobject=0.2;%正方形物体长宽都是0.2m！！！！！！！！！！！！！
% d0_loomingobject=5;%物体与摄像头的初始距离！！！！！！！！！！！！！
% d_stop=l_loomingobject/(tan(min(HFOV,VFOV)*pi/180));%物体停下时与摄像头的距离
% % 图像参数
% % screenXpix = 960;                   % 屏幕的水平像素数
% % screenYpix = 720;                   % 屏幕的垂直像素数
% screenXpix = 320;                   % 屏幕的水平像素数
% screenYpix = 240;                   % 屏幕的垂直像素数
% 
% x_scale=screenXpix/xx;
% y_scale=screenYpix/yy;
% xCenter = round(screenXpix/2)+1;      % 屏幕的水平中心位置
% yCenter = round(screenYpix/2)+1;      % 屏幕的垂直中心位置
% % real world or pixel motion velocity!!!!!!!!!!!!!!!!!!
% v0=[1,2,3,4,5];
% % 初始位置
% % picture = zeros(screenYpix,screenXpix,frame);  
% figure(1)
% for j=1:5
%     v=v0(j)
%     FilePath_looming = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\real world\d=5 v=';
%     FilePath_looming = strcat(FilePath_looming,num2str(v0(j)),' looming\');
%     
% %     FilePath_looming = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\pixel motion\d=5 v=';
% %     FilePath_looming = strcat(FilePath_looming,num2str(v0(j)),' looming\');
% 
%     t = (d0_loomingobject-d_stop)/v;                              % 时间间隔
%     refresh_rate = 30;                 % 刷新率
%     frame = floor(refresh_rate*t);            % 总帧数
%     picture = zeros(screenYpix+1,screenXpix+1,frame);
%     for idx=1:frame*100
%         dtc=d0_loomingobject-v*idx/refresh_rate;
%         %real
%         length_x = x_scale*l_loomingobject*f/dtc; % 物体在屏幕x上的长度
%         length_y = y_scale*l_loomingobject*f/dtc; % 物体在屏幕y上的长度
%         %-------pixel------------------- 
% %         length_x = 2*v*idx+round(x_scale*l_loomingobject*f/d0_loomingobject); % 物体在屏幕x上的长度
% %         length_y = 2*v*idx+round(y_scale*l_loomingobject*f/d0_loomingobject); % 物体在屏幕y上的长度
%         if (length_y/2)>=screenYpix/2
%             break
%         end
% 
%         up   = round(-length_y/2+yCenter);
%         down   = round(length_y/2+yCenter);
%         left   = round(-length_x/2+xCenter);
%         right   = round(length_x/2+xCenter);
%         up(up<1)=1;down(down<1)=1;left(left<1)=1;right(right<1)=1;
% 
% 
%         picture(up:down,left:right,idx) = 1;    % 将物体的区域设置为1，即白色
%     
%         %显示并保存
%         imshow(picture(:,:,idx));
%         title(strcat('P',num2str(idx-1)));
% 
%         imwrite(picture(:,:,idx),strcat(FilePath_looming,num2str(idx),'.bmp'));
%         drawnow; % 更新图像
%         pause(0.001); % 延迟0.1秒，以观察每一帧的图像  
%     end
% end
% 
%%------------------------------------translate----------------------------
v=1;%真实平移速度
%摄像头参数
clear clc
f=0.0028;HFOV=77.8;VFOV=55.6;xx=0.0048;yy=0.0036;
l_loomingobject=0.2;%正方形物体长宽都是0.2m
d0_loomingobject=5;%物体与摄像头的初始距离
% d_stop=l_loomingobject/(tan(min(HFOV,VFOV)*pi/180));%物体停下时与摄像头的距离
d_stop_x=d0_loomingobject*(tan(HFOV*pi/180))-l_loomingobject/2%----------物体平移超出视野边界---------
%图像参数
screenXpix = 320;                   % 屏幕的水平像素数
screenYpix = 240;                   % 屏幕的垂直像素数
x_scale=screenXpix/xx;
y_scale=screenYpix/yy;
xCenter = round(screenXpix/2)+1;      % 屏幕的水平中心位置
yCenter = round(screenYpix/2)+1;      % 屏幕的垂直中心位置
%real world or pixel motion velocity!!!!!!!!!!!!!!!!!!
v0=[1,2,3,4,5];

length_x = x_scale*l_loomingobject*f/d0_loomingobject % 物体在屏幕x上的长度
length_y = y_scale*l_loomingobject*f/d0_loomingobject;
up   = 1;
down   = length_y+1;

%初始位置
% picture = zeros(screenYpix,screenXpix,frame);  
picture_sum=zeros(screenYpix+1,screenXpix+1,51);
figure(1)
for j=1:5
    v=v0(j);
    FilePath_translate = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\pixel motion\compounded translate\';
%     FilePath_translate = strcat(FilePath_translate,num2str(v0(j)),' translate\');

%     FilePath_translate = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\pixel motion\d=5 v=';
%     FilePath_translate = strcat(FilePath_translate,num2str(v0(j)),' translate\');

    t = d_stop_x/v;                             % 时间间隔
    refresh_rate = 30;                 % 刷新率
    frame = floor(refresh_rate*t);            % 总帧数
    picture = zeros(screenYpix+1,screenXpix+1,frame);
    left   = 0;
    right   = length_x;
    for idx=1:frame
    %translate
        d_x = v * idx / refresh_rate; % 计算物体在真实世界中的水平位移
        d_x_image = y_scale*d_x * f / d0_loomingobject;  % 计算物体在图像上的水平位移        
        
        %-------pixel-------------------    
%         d_x_image = j*idx;
        if idx>=51
            break
        end

        left   = round(0+d_x_image);
        right   = round(length_x+d_x_image);

        picture(up:down,left:right,idx) = 1;    % 将物体的区域设置为1，即白色

        %显示并保存
        imshow(picture(:,:,idx));
        title(strcat('P',num2str(idx-1)));
        picture_sum(:,:,idx)=picture_sum(:,:,idx)+picture(:,:,idx);
        imwrite(picture_sum(:,:,idx),strcat(FilePath_translate,num2str(idx),'.bmp'));
        drawnow; % 更新图像
        pause(0.001); % 延迟0.1秒，以观察每一帧的图像  
    end
    up   = up+40;
    down   = down+40;
end



%------------------------------------ looming translate【111112222233333444445555566666】----------------------------
v=1;%真实平移速度
%摄像头参数
clear clc
f=0.0028;HFOV=77.8;VFOV=55.6;xx=0.0048;yy=0.0036;
l_loomingobject=0.2;%正方形物体长宽都是0.2m
d0_loomingobject=5;%物体与摄像头的初始距离
% d_stop=l_loomingobject/(tan(min(HFOV,VFOV)*pi/180));%物体停下时与摄像头的距离
d_stop_x=d0_loomingobject*(tan(HFOV*pi/180))-l_loomingobject/2;%----------物体平移超出视野边界---------
%图像参数
% screenXpix = 960;                   % 屏幕的水平像素数
% screenYpix = 720;                   % 屏幕的垂直像素数

screenXpix = 320;                   % 屏幕的水平像素数
screenYpix = 240;                   % 屏幕的垂直像素数
x_scale=screenXpix/xx;
y_scale=screenYpix/yy;
xCenter = round(screenXpix/2);      % 屏幕的水平中心位置
yCenter = round(screenYpix/2);      % 屏幕的垂直中心位置
%real world or pixel motion velocity!!!!!!!!!!!!!!!!!!
v0=[1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4,5,5,5,5,5,6,6,6,6,6,7,7,7,7,7,8,8,8,8,8,9,9,9,9,9];
%初始位置
frame=31;
picture_looming = zeros(screenYpix,screenXpix,frame);  
picture_translate = zeros(screenYpix,screenXpix,51); 
FilePath_translate = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\pixel motion\compounded translate\\';

% FilePath_looming = 'C:\Users\Administrator\Desktop\acc_sum\code\A_realtime\compounded looming and translate\240320\pixel motion\d=5 v=12345 looming\';
d_x_image=0;
length_x=0;
length_y=0;
%looming
length_x0=x_scale*l_loomingobject*f/d0_loomingobject;
length_x=x_scale*l_loomingobject*f/d0_loomingobject;
length_y=y_scale*l_loomingobject*f/d0_loomingobject;

for j=1:51
    v=v0(j);
    picture_looming = zeros(screenYpix,screenXpix,j);  
    picture_translate = zeros(screenYpix+1,screenXpix+1,j); 
    

% %     -------pixel_translate-------------------    
        d_x_image = d_x_image+v
        length_x = x_scale*l_loomingobject*f/d0_loomingobject; % 物体在屏幕x上的长度
        length_y = y_scale*l_loomingobject*f/d0_loomingobject;
        if d_x_image>=screenXpix
            break
        end

%         up   = round(-length_y/2+yCenter);
%         down   = round(length_y/2+yCenter);
        left   = round(0+d_x_image);
        right   = round(length_x+d_x_image);
        picture_translate(up:down,left:right,j) = 1;    % 将物体的区域设置为1，即白色

        %显示并保存
        figure(1)
        imshow(picture_translate(:,:,j));
        title(strcat('P',num2str(j-1)));
        picture_sum(:,:,j)=picture_sum(:,:,j)+picture_translate(:,:,j);
        imwrite(picture_sum(:,:,j),strcat(FilePath_translate,num2str(j),'.bmp'));
        drawnow; % 更新图像
        pause(0.001); % 延迟0.1秒，以观察每一帧的图像 
%     %------pixel_looming------------------
%     t = d_stop_x/v;                             % 时间间隔
%     refresh_rate = 30;                 % 刷新率
%     frame = floor(refresh_rate*t);            % 总帧数
%     picture1 = zeros(screenYpix,screenXpix,frame);
%     %translate
%         d_x = v * j / refresh_rate; % 计算物体在真实世界中的水平位移
%         d_x_image = y_scale*d_x * f / d0_loomingobject;  % 计算物体在图像上的水平位移        
% %         length_x = x_scale*l_loomingobject*f/d0_loomingobject; % 物体在屏幕x上的长度
% %         length_y = y_scale*l_loomingobject*f/d0_loomingobject;
% %         if d_x_image+(length_x0/2)>=screenXpix/2
% %             break
% %         end
%         
%         length_x =length_x+ 2*v % 物体在屏幕x上的长度
%         length_y =length_y+ 2*v; % 物体在屏幕y上的长度
%         up   = round(-length_y/2+yCenter);
%         down   = round(length_y/2+yCenter);
%         left   = round(-length_x/2+xCenter);
%         right   = round(length_x/2+xCenter);
%         up(up<1)=1;down(down<1)=1;left(left<1)=1;right(right<1)=1;
% 
% 
%         picture_looming(up:down,left:right,j) = 1;    % 将物体的区域设置为1，即白色
%     
%         %显示并保存
%         figure(2)
%         imshow(picture_looming(:,:,j));
%         title(strcat('P',num2str(j-1)));
%         imwrite(picture_looming(:,:,j),strcat(FilePath_looming,num2str(j),'.bmp'));
%         drawnow; % 更新图像
%         pause(0.001); % 延迟0.1秒，以观察每一帧的图像      
end